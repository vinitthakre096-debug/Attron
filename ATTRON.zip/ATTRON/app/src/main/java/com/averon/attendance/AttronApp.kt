package com.averon.attendance

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.averon.attendance.data.AppDatabase
import com.averon.attendance.data.Repo
import com.averon.attendance.data.SettingsStore

class AttronApp : Application() {
    lateinit var db: AppDatabase
        private set
    lateinit var settings: SettingsStore
        private set
    lateinit var repo: Repo
        private set

    override fun onCreate() {
        super.onCreate()
        db = AppDatabase.build(this)
        settings = SettingsStore(this)
        repo = Repo(db)

        val channel = NotificationChannel(
            CHANNEL_ID,
            "Attendance reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Reminders to mark attendance when a lecture ends" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ID = "attendance_reminders"
    }
}

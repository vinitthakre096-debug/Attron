package com.averon.attendance.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.averon.attendance.data.AppTheme
import kotlinx.coroutines.delay

@Composable
fun AttronSplashScreen(onFinished: () -> Unit) {
    var targetProgress by remember { mutableFloatStateOf(0.15f) }
    val animatedProgress by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
        label = "splash_progress"
    )

    LaunchedEffect(Unit) {
        targetProgress = 1f
        delay(1450)
        onFinished()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Full-bleed sunlit valley & misty mountain backdrop
        ValleyScenicBackdrop(
            theme = AppTheme.BREEZE,
            modifier = Modifier.fillMaxSize(),
            showSun = true
        )

        // Top-left botanical green leaves
        CornerBotanicalLeaves(
            modifier = Modifier
                .align(Alignment.TopStart)
                .width(190.dp)
                .height(175.dp)
        )

        // Center ATTRON emblem, serif wordmark & tagline
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(bottom = 60.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AttronLeafLogo(size = 64.dp)
            Spacer(Modifier.height(10.dp))
            Text(
                text = "ATTRON",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 34.sp,
                letterSpacing = 1.5.sp,
                color = Color(0xFF1D241E)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Your College Companion",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFF3E4A40)
            )
        }

        // Bottom centered progress pill matching reference image
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 52.dp)
                .width(96.dp)
                .height(6.dp)
                .clip(CircleShape)
                .background(Color(0x559AA59B))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedProgress)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(Color(0xFF4B8B47))
            )
        }
    }
}

@Composable
fun OnboardingScreen(
    initialName: String,
    initialSubtitle: String,
    onContinue: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var subtitle by remember { mutableStateOf(initialSubtitle) }

    Box(modifier = Modifier.fillMaxSize()) {
        ValleyScenicBackdrop(
            theme = AppTheme.BREEZE,
            modifier = Modifier.fillMaxSize(),
            showSun = true
        )
        CornerBotanicalLeaves(
            modifier = Modifier
                .align(Alignment.TopStart)
                .width(170.dp)
                .height(155.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GlassCard(containerAlpha = 0.92f, cornerRadius = 26.dp) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AttronLeafLogo(size = 48.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Welcome to ATTRON",
                        style = MaterialTheme.typography.headlineSmall,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Offline-first attendance & timetable companion designed for calm, effortless tracking.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Your Name") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = subtitle,
                        onValueChange = { subtitle = it },
                        label = { Text("Course & Semester (e.g. BTech CSE · Sem 1)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = { onContinue(name, subtitle) },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text("Get Started", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

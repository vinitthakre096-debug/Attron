package com.averon.attendance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.DAY_NAMES
import com.averon.attendance.data.Status
import com.averon.attendance.data.Subject
import com.averon.attendance.data.TimetableEntry
import com.averon.attendance.data.TimetableTabCategory
import com.averon.attendance.data.fmtDate
import com.averon.attendance.data.fmtTime
import com.averon.attendance.ocr.DraftEntry

@Composable
fun StatusPicker(selected: Status, onSelect: (Status) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Status.entries.forEach { s ->
            FilterChip(selected = selected == s, onClick = { onSelect(s) }, label = { Text(s.label) })
        }
    }
}

@Composable
fun ProfileEditDialog(
    currentName: String,
    currentSubtitle: String,
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var subtitle by remember { mutableStateOf(currentSubtitle) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Edit Profile") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Your Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subtitle,
                    onValueChange = { subtitle = it },
                    label = { Text("Course & Semester") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name, subtitle) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ReplacementDialog(
    entry: TimetableEntry,
    subjects: List<Subject>,
    onConfirm: (subjectId: Long, status: Status) -> Unit,
    onDismiss: () -> Unit
) {
    val options = subjects.filter { it.id != entry.subjectId }
    var picked by remember { mutableStateOf<Subject?>(null) }
    var status by remember { mutableStateOf(Status.PRESENT) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Replacement class") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Which subject was actually taught in this slot?")
                if (options.isEmpty()) {
                    Text("Add another subject first.", color = MaterialTheme.colorScheme.error)
                }
                DropdownField("Select subject", options, picked, { it.name }) { picked = it }
                StatusPicker(status) { status = it }
                Text(
                    "Attendance is recorded for the subject that was taught.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(enabled = picked != null, onClick = { onConfirm(picked!!.id, status) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ExtraClassDialog(
    subjects: List<Subject>,
    defaultDate: Long,
    onSave: (subjectId: Long, date: Long, start: Int, end: Int, room: String, status: Status) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var subject by remember { mutableStateOf<Subject?>(null) }
    var date by remember { mutableLongStateOf(defaultDate) }
    var start by remember { mutableIntStateOf(16 * 60) }
    var end by remember { mutableIntStateOf(17 * 60) }
    var room by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(Status.PRESENT) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Add extra class") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DropdownField("Select subject", subjects, subject, { it.name }) { subject = it }
                OutlinedButton(
                    onClick = { pickDate(ctx, date) { date = it } },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(fmtDate(date)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { pickTime(ctx, start) { start = it } },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(fmtTime(start)) }
                    Text("to")
                    OutlinedButton(
                        onClick = { pickTime(ctx, end) { end = it } },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(fmtTime(end)) }
                }
                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("Room (e.g. A-201)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                StatusPicker(status) { status = it }
                if (end <= start) {
                    Text("End time must be after start time.", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = subject != null && end > start,
                onClick = { onSave(subject!!.id, date, start, end, room.trim(), status) }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun EntryDialog(
    initial: TimetableEntry?,
    subjects: List<Subject>,
    defaultDay: Int,
    defaultCategory: TimetableTabCategory = TimetableTabCategory.REGULAR,
    onSave: (TimetableEntry) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var subject by remember { mutableStateOf(subjects.firstOrNull { it.id == initial?.subjectId }) }
    var day by remember { mutableIntStateOf(initial?.dayOfWeek ?: defaultDay) }
    var start by remember { mutableIntStateOf(initial?.startMin ?: (10 * 60)) }
    var end by remember { mutableIntStateOf(initial?.endMin ?: (11 * 60)) }
    var room by remember { mutableStateOf(initial?.room ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: defaultCategory) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text(if (initial == null) "Add Timetable Class" else "Edit Timetable Class") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DropdownField("Select subject", subjects, subject, { "${it.shortName} · ${it.name}" }) { subject = it }
                DropdownField("Weekday", (1..7).toList(), day, { DAY_NAMES[it - 1] }) { day = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { pickTime(ctx, start) { start = it } },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(fmtTime(start)) }
                    Text("to")
                    OutlinedButton(
                        onClick = { pickTime(ctx, end) { end = it } },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(fmtTime(end)) }
                }
                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("Room / Lab (e.g. A-201, Lab 1)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Class Type", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TimetableTabCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.label) }
                        )
                    }
                }
                if (end <= start) {
                    Text("End time must be after start time.", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = subject != null && end > start,
                onClick = {
                    onSave(
                        TimetableEntry(
                            id = initial?.id ?: 0L,
                            subjectId = subject!!.id,
                            dayOfWeek = day,
                            startMin = start,
                            endMin = end,
                            room = room.trim(),
                            isExtra = category == TimetableTabCategory.EXTRA,
                            isTemporary = category == TimetableTabCategory.TEMPORARY,
                            active = initial?.active ?: true
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun OcrPreviewDialog(
    drafts: List<DraftEntry>,
    subjects: List<Subject>,
    onSave: (List<DraftEntry>) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val rows = remember { mutableStateListOf<DraftEntry>().apply { addAll(drafts) } }
    val ready = rows.count { it.subjectId != null }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Review Detected Timetable") },
        text = {
            Column {
                Text(
                    "Verify subject, weekday, time, and room before saving. Unmapped rows are skipped.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    itemsIndexed(rows) { i, d ->
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "Detected: ${d.label.ifBlank { "(no text)" }}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DropdownField("Day", (1..7).toList(), d.day, { DAY_NAMES[it - 1] }, Modifier.weight(1f)) {
                                    rows[i] = d.copy(day = it)
                                }
                                DropdownField(
                                    "Subject",
                                    subjects,
                                    subjects.firstOrNull { it.id == d.subjectId },
                                    { it.shortName },
                                    Modifier.weight(1.4f)
                                ) { rows[i] = d.copy(subjectId = it.id) }
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { pickTime(ctx, d.startMin) { rows[i] = d.copy(startMin = it) } },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) { Text(fmtTime(d.startMin), maxLines = 1) }
                                Text("–")
                                OutlinedButton(
                                    onClick = { pickTime(ctx, d.endMin) { rows[i] = d.copy(endMin = it) } },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) { Text(fmtTime(d.endMin), maxLines = 1) }
                                IconButton(onClick = { rows.removeAt(i) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove row")
                                }
                            }
                            OutlinedTextField(
                                value = d.room,
                                onValueChange = { rows[i] = d.copy(room = it) },
                                label = { Text("Room") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = ready > 0, onClick = { onSave(rows.toList()) }) { Text("Save $ready") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Discard") } }
    )
}

private val palette = listOf(
    0xFF4B8B47L, 0xFFE05A5AL, 0xFFE5A93BL, 0xFF3E8BE0L,
    0xFF8F7BB8L, 0xFF4FA3A5L, 0xFFC98B5BL, 0xFF8A8F98L
)

@Composable
fun SubjectDialog(initial: Subject?, onSave: (Subject) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var short by remember { mutableStateOf(initial?.shortName ?: "") }
    var color by remember { mutableStateOf(initial?.color ?: palette.first()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text(if (initial == null) "Add subject" else "Edit subject") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full name (e.g. Basic Electrical Engineering)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = short,
                    onValueChange = { short = it },
                    label = { Text("Short name (e.g. BEE)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Accent Colour", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    palette.forEach { c ->
                        val selected = c == color
                        Box(
                            Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .then(
                                    if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                    else Modifier
                                )
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && short.isNotBlank(),
                onClick = {
                    onSave(Subject(id = initial?.id ?: 0L, name = name.trim(), shortName = short.trim(), color = color))
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun EditRecordDialog(
    record: AttendanceRecord,
    subjectName: String,
    onSave: (AttendanceRecord) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var status by remember { mutableStateOf(record.status) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text(subjectName) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "${fmtDate(record.date)} · ${fmtTime(record.startMin)} – ${fmtTime(record.endMin)} · ${record.type.label}",
                    style = MaterialTheme.typography.bodySmall
                )
                StatusPicker(status) { status = it }
                Text(
                    "Off classes are excluded from attendance percentages.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(record.copy(status = status)) }) { Text("Save") } },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                Spacer(Modifier.width(4.dp))
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

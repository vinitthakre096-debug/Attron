package com.averon.attendance.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY name COLLATE NOCASE")
    fun all(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects")
    suspend fun allOnce(): List<Subject>

    @Query("SELECT * FROM subjects WHERE id = :id")
    suspend fun get(id: Long): Subject?

    @Insert
    suspend fun insert(subject: Subject): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<Subject>)

    @Update
    suspend fun update(subject: Subject)

    @Delete
    suspend fun delete(subject: Subject)

    @Query("DELETE FROM subjects")
    suspend fun deleteAll()
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable ORDER BY dayOfWeek, startMin")
    fun all(): Flow<List<TimetableEntry>>

    @Query("SELECT * FROM timetable")
    suspend fun allOnce(): List<TimetableEntry>

    @Query("SELECT * FROM timetable WHERE subjectId = :subjectId")
    suspend fun bySubject(subjectId: Long): List<TimetableEntry>

    @Query("SELECT * FROM timetable WHERE id = :id")
    suspend fun get(id: Long): TimetableEntry?

    @Insert
    suspend fun insert(entry: TimetableEntry): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<TimetableEntry>)

    @Update
    suspend fun update(entry: TimetableEntry)

    @Delete
    suspend fun delete(entry: TimetableEntry)

    @Query("DELETE FROM timetable")
    suspend fun deleteAll()
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance ORDER BY date DESC, startMin DESC")
    fun all(): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance")
    suspend fun allOnce(): List<AttendanceRecord>

    @Query("SELECT * FROM attendance WHERE timetableEntryId = :entryId AND date = :date LIMIT 1")
    suspend fun find(entryId: Long, date: Long): AttendanceRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: AttendanceRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<AttendanceRecord>)

    @Delete
    suspend fun delete(record: AttendanceRecord)

    @Query("DELETE FROM attendance")
    suspend fun deleteAll()
}

package com.averon.attendance.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class AppTheme(val label: String) {
    SYSTEM("System"),
    BREEZE("Breeze (light)"),
    DUSK("Dusk (dark)")
}

data class AppSettings(
    val theme: AppTheme = AppTheme.SYSTEM,
    val target: Int = 75,
    val notifications: Boolean = true
)

private val Context.dataStore by preferencesDataStore(name = "attron_settings")

class SettingsStore(private val ctx: Context) {
    private val themeKey = stringPreferencesKey("theme")
    private val targetKey = intPreferencesKey("target")
    private val notifKey = booleanPreferencesKey("notifications")

    val flow: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        AppSettings(
            theme = runCatching { AppTheme.valueOf(p[themeKey] ?: "SYSTEM") }.getOrDefault(AppTheme.SYSTEM),
            target = p[targetKey] ?: 75,
            notifications = p[notifKey] ?: true
        )
    }

    suspend fun setTheme(t: AppTheme) {
        ctx.dataStore.edit { it[themeKey] = t.name }
    }

    suspend fun setTarget(v: Int) {
        ctx.dataStore.edit { it[targetKey] = v }
    }

    suspend fun setNotifications(v: Boolean) {
        ctx.dataStore.edit { it[notifKey] = v }
    }
}

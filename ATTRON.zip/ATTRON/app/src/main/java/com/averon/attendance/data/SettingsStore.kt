package com.averon.attendance.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class AppTheme(val label: String, val subtitle: String) {
    BREEZE("Breeze", "Default"),
    MIDNIGHT("Midnight", "Dark and premium"),
    LAVENDER("Lavender", "Soft purple"),
    MOCHA("Mocha", "Warm neutral"),
    ARCTIC("Arctic", "Cool blue"),
    ROSE("Rose", "Dusty pink")
}

enum class AppBackground(val label: String, val drawableName: String) {
    MOUNTAIN("Mountain", "bg_mountain"),
    ARCH_STUDIO("Arch Studio", "bg_arch_studio"),
    DREAM_CLOUD("Dream Cloud", "bg_dream_cloud"),
    GLASS_ORBS("Glass Orbs", "bg_glass_orbs"),
    OCEAN_TEXTURE("Ocean Texture", "bg_ocean_texture"),
    MISTY_FOREST("Misty Forest", "bg_misty_forest")
}

val ACCENT_PALETTE = listOf(
    0xFF4B8B47L, // Sage Leaf Green (Default)
    0xFF8EC5E8L, // Sky Mist Blue
    0xFFCBA3E8L, // Lavender Twilight
    0xFFF29CA3L, // Blossom Coral
    0xFFF6BA6FL  // Warm Amber Sun
)

data class AppSettings(
    val theme: AppTheme = AppTheme.BREEZE,
    val accentColor: Long = 0xFF4B8B47L,
    val background: AppBackground = AppBackground.MOUNTAIN,
    val target: Int = 75,
    val notifications: Boolean = true,
    val userName: String = "Vinit",
    val userSubtitle: String = "BTech CSE · Sem 1",
    val onboardingDone: Boolean = false
)

private val Context.dataStore by preferencesDataStore(name = "attron_settings")

class SettingsStore(private val ctx: Context) {
    private val themeKey = stringPreferencesKey("theme")
    private val accentKey = longPreferencesKey("accent_color")
    private val backgroundKey = stringPreferencesKey("background")
    private val targetKey = intPreferencesKey("target")
    private val notifKey = booleanPreferencesKey("notifications")
    private val nameKey = stringPreferencesKey("user_name")
    private val subtitleKey = stringPreferencesKey("user_subtitle")
    private val onboardingKey = booleanPreferencesKey("onboarding_done")

    val flow: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        val rawTheme = p[themeKey] ?: AppTheme.BREEZE.name
        val parsedTheme = when (rawTheme) {
            "SYSTEM" -> AppTheme.BREEZE
            else -> runCatching { AppTheme.valueOf(rawTheme) }.getOrDefault(AppTheme.BREEZE)
        }
        AppSettings(
            theme = parsedTheme,
            accentColor = p[accentKey] ?: 0xFF4B8B47L,
            background = runCatching { AppBackground.valueOf(p[backgroundKey] ?: AppBackground.MOUNTAIN.name) }.getOrDefault(AppBackground.MOUNTAIN),
            target = p[targetKey] ?: 75,
            notifications = p[notifKey] ?: true,
            userName = p[nameKey] ?: "Vinit",
            userSubtitle = p[subtitleKey] ?: "BTech CSE · Sem 1",
            onboardingDone = p[onboardingKey] ?: false
        )
    }

    suspend fun setTheme(t: AppTheme) {
        ctx.dataStore.edit { it[themeKey] = t.name }
    }

    suspend fun setBackground(background: AppBackground) {
        ctx.dataStore.edit { it[backgroundKey] = background.name }
    }

    suspend fun setAccent(color: Long) {
        ctx.dataStore.edit { it[accentKey] = color }
    }

    suspend fun setTarget(v: Int) {
        ctx.dataStore.edit { it[targetKey] = v }
    }

    suspend fun setNotifications(v: Boolean) {
        ctx.dataStore.edit { it[notifKey] = v }
    }

    suspend fun setProfile(name: String, subtitle: String) {
        ctx.dataStore.edit {
            it[nameKey] = name.trim().ifEmpty { "Student" }
            it[subtitleKey] = subtitle.trim()
        }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        ctx.dataStore.edit { it[onboardingKey] = done }
    }
}

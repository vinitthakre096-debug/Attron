package com.averon.attendance.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.averon.attendance.data.AppTheme
import java.io.File

@Composable
fun ImportTimetableScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val subjects by vm.subjects.collectAsState()
    val drafts by vm.drafts.collectAsState()
    val scanning by vm.scanning.collectAsState()

    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) vm.scan(uri)
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            vm.scan(uri)
        }
    }

    fun launchCameraCapture() {
        if (subjects.isEmpty()) {
            Toast.makeText(ctx, "Add subjects first in More → Subjects", Toast.LENGTH_SHORT).show()
            return
        }
        val imageFile = File(ctx.cacheDir, "timetable_capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", imageFile)
        pendingCameraUri = uri
        cameraLauncher.launch(uri)
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchCameraCapture()
        } else {
            Toast.makeText(ctx, "Camera permission is required to scan timetable", Toast.LENGTH_SHORT).show()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Import Timetable", onBack = onBack)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Illustrated Scanner Card matching Reference Screen #6
            Box(
                modifier = Modifier.size(210.dp),
                contentAlignment = Alignment.Center
            ) {
                // Botanical leaves peeking behind the tilted scanner card
                CornerBotanicalLeaves(
                    flipVertical = true,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .size(110.dp)
                )

                // Back tilted translucent sheet
                Surface(
                    modifier = Modifier
                        .size(146.dp)
                        .rotate(-8f),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                ) {}

                // Front tilted scanner viewfinder card
                Surface(
                    modifier = Modifier
                        .size(146.dp)
                        .rotate(4f),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 4.dp,
                    border = BorderStroke(1.5.dp, Color.White)
                ) {
                    Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                        ValleyScenicBackdrop(
                            theme = AppTheme.BREEZE,
                            modifier = Modifier.fillMaxSize(),
                            showSun = false
                        )
                        // Viewfinder corner brackets
                        Canvas(modifier = Modifier.fillMaxSize().padding(18.dp)) {
                            val w = size.width
                            val h = size.height
                            val b = 18.dp.toPx()
                            val stroke = 2.5.dp.toPx()
                            val c = Color(0xFF1E2620)

                            // Top-left
                            drawPath(Path().apply { moveTo(0f, b); lineTo(0f, 0f); lineTo(b, 0f) }, c, style = Stroke(stroke, cap = StrokeCap.Round))
                            // Top-right
                            drawPath(Path().apply { moveTo(w - b, 0f); lineTo(w, 0f); lineTo(w, b) }, c, style = Stroke(stroke, cap = StrokeCap.Round))
                            // Bottom-left
                            drawPath(Path().apply { moveTo(0f, h - b); lineTo(0f, h); lineTo(b, h) }, c, style = Stroke(stroke, cap = StrokeCap.Round))
                            // Bottom-right
                            drawPath(Path().apply { moveTo(w - b, h); lineTo(w, h); lineTo(w, h - b) }, c, style = Stroke(stroke, cap = StrokeCap.Round))

                            // Mountain icon inside viewfinder
                            val mPath = Path().apply {
                                moveTo(w * 0.25f, h * 0.68f)
                                lineTo(w * 0.44f, h * 0.42f)
                                lineTo(w * 0.56f, h * 0.58f)
                                lineTo(w * 0.66f, h * 0.48f)
                                lineTo(w * 0.78f, h * 0.68f)
                                close()
                            }
                            drawPath(mPath, c, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
                            drawCircle(c, radius = 3.dp.toPx(), center = Offset(w * 0.64f, h * 0.32f))
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            Text(
                text = "Scan Timetable",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Capture your class timetable
and we'll set it up for you.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (scanning) {
                Spacer(Modifier.height(20.dp))
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                Text("Detecting classes with OCR...", style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(28.dp))

            // Primary Sage-Green Button: Scan with Camera
            Button(
                onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        launchCameraCapture()
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                enabled = !scanning,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(Icons.Outlined.CameraAlt, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(10.dp))
                Text("Scan with Camera", style = MaterialTheme.typography.labelLarge, color = Color.White)
            }

            Spacer(Modifier.height(12.dp))

            // Secondary Soft Glass Button: Choose from Gallery
            OutlinedButton(
                onClick = {
                    if (subjects.isEmpty()) {
                        Toast.makeText(ctx, "Add subjects first in More → Subjects", Toast.LENGTH_SHORT).show()
                    } else {
                        galleryLauncher.launch("image/*")
                    }
                },
                enabled = !scanning,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(Icons.Outlined.Image, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text("Choose from Gallery", style = MaterialTheme.typography.labelLarge)
            }
        }
    }

    // Mandatory Editable Preview Dialog before saving OCR output
    drafts?.let { detected ->
        OcrPreviewDialog(
            drafts = detected,
            subjects = subjects,
            onSave = { confirmed ->
                vm.saveDrafts(confirmed)
                onBack()
            },
            onDismiss = { vm.discardDrafts() }
        )
    }
}

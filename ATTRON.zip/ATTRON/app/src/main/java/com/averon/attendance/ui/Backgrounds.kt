package com.averon.attendance.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.averon.attendance.R
import com.averon.attendance.data.AppBackground
import com.averon.attendance.data.AppTheme

@Composable
fun AttronBackground(
    background: AppBackground,
    theme: AppTheme,
    modifier: Modifier = Modifier
) {
    when (background) {
        AppBackground.MOUNTAIN -> ValleyScenicBackdrop(theme, modifier, true)
        AppBackground.OCEAN_TEXTURE -> Image(painterResource(R.drawable.bg_ocean_texture), null, modifier, contentScale = ContentScale.Crop)
        AppBackground.MISTY_FOREST -> Image(painterResource(R.drawable.bg_misty_forest), null, modifier, contentScale = ContentScale.Crop)
        AppBackground.ARCH_STUDIO -> Canvas(modifier) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFF0E5D8), Color(0xFFFCF8F1), Color(0xFFD8C8B8))))
            val cx = size.width * .52f
            for (i in 0..3) {
                val width = size.width * (.88f - i * .16f)
                val top = size.height * (.12f + i * .09f)
                val p = Path().apply {
                    moveTo(cx - width / 2, size.height * 1.08f)
                    lineTo(cx - width / 2, top + width * .34f)
                    quadraticTo(cx - width / 2, top, cx, top)
                    quadraticTo(cx + width / 2, top, cx + width / 2, top + width * .34f)
                    lineTo(cx + width / 2, size.height * 1.08f)
                }
                drawPath(p, Color(0xFFB7A28F).copy(alpha = .15f + i * .05f), style = Stroke(width = 2f))
            }
        }
        AppBackground.DREAM_CLOUD -> Canvas(modifier) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF9CBDEB), Color(0xFFF3D9E5), Color(0xFFFFE7D5))))
            val cloud = Color(0xFFFFF7F6).copy(alpha = .78f)
            listOf(Offset(size.width*.12f,size.height*.28f), Offset(size.width*.83f,size.height*.22f), Offset(size.width*.5f,size.height*.72f), Offset(size.width*.08f,size.height*.84f)).forEachIndexed { i, c ->
                val r = size.width * if (i == 2) .20f else .14f
                drawCircle(cloud, r, c); drawCircle(cloud.copy(alpha=.55f), r*.72f, c + Offset(r*.7f, r*.12f))
            }
        }
        AppBackground.GLASS_ORBS -> Canvas(modifier) {
            drawRect(Brush.linearGradient(listOf(Color(0xFFE9F2F0), Color(0xFFF7F3F0), Color(0xFFDCEBE8))))
            listOf(Offset(size.width*.78f,size.height*.20f), Offset(size.width*.15f,size.height*.62f), Offset(size.width*.85f,size.height*.83f), Offset(size.width*.42f,size.height*.08f)).forEachIndexed { i, c ->
                val r = size.width * if (i == 1) .23f else .16f
                drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha=.85f), Color(0xFF9ECBC7).copy(alpha=.16f), Color.Transparent), c, r), r, c)
                drawCircle(Color.White.copy(alpha=.55f), r, c, style = Stroke(width=2f))
            }
        }
    }
}

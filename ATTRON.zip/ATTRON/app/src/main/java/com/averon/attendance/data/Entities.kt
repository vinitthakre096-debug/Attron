package com.averon.attendance.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class Status(val label: String) {
    PRESENT("Present"),
    ABSENT("Absent"),
    OFF("Off")
}

enum class ClassType(val label: String) {
    REGULAR("Regular"),
    REPLACEMENT("Replacement"),
    EXTRA("Extra"),
    TEMPORARY("Temporary")
}

enum class TimetableTabCategory(val label: String) {
    REGULAR("Regular"),
    TEMPORARY("Temporary"),
    EXTRA("Extra")
}

@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val shortName: String,
    /** ARGB colour, e.g. 0xFF4F8A4B */
    val color: Long
)

@Entity(
    tableName = "timetable",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class TimetableEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    /** 1 = Monday ... 7 = Sunday */
    val dayOfWeek: Int,
    val startMin: Int,
    val endMin: Int,
    val room: String = "",
    val isExtra: Boolean = false,
    val isTemporary: Boolean = false,
    val active: Boolean = true
) {
    val category: TimetableTabCategory
        get() = when {
            isTemporary -> TimetableTabCategory.TEMPORARY
            isExtra -> TimetableTabCategory.EXTRA
            else -> TimetableTabCategory.REGULAR
        }
}

@Entity(
    tableName = "attendance",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TimetableEntry::class,
            parentColumns = ["id"],
            childColumns = ["timetableEntryId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index("subjectId"),
        Index("timetableEntryId"),
        Index(value = ["timetableEntryId", "date"], unique = true)
    ]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    /** LocalDate epoch day */
    val date: Long,
    val startMin: Int,
    val endMin: Int,
    val status: Status,
    val type: ClassType,
    val timetableEntryId: Long? = null,
    val scheduledSubjectId: Long? = null,
    val room: String = ""
)

package com.averon.attendance.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.DAY_NAMES
import com.averon.attendance.data.TimetableEntry
import com.averon.attendance.data.fmtTime
import java.time.LocalDate

@Composable
fun TimetableScreen(vm: MainViewModel) {
    val subjects by vm.subjects.collectAsState()
    val entries by vm.entries.collectAsState()
    val drafts by vm.drafts.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val subjMap = remember(subjects) { subjects.associateBy { it.id } }

    var day by remember { mutableIntStateOf(LocalDate.now().dayOfWeek.value) }
    var editing by remember { mutableStateOf<TimetableEntry?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<TimetableEntry?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.scan(uri)
    }

    val dayEntries = entries.filter { it.dayOfWeek == day }.sortedBy { it.startMin }

    Column(Modifier.fillMaxSize()) {
        PageTitle("Timetable")
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DAY_NAMES.forEachIndexed { i, name ->
                FilterChip(selected = day == i + 1, onClick = { day = i + 1 }, label = { Text(name) })
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = { adding = true }, enabled = subjects.isNotEmpty(), modifier = Modifier.weight(1f)) {
                Text("Add class")
            }
            OutlinedButton(
                onClick = { picker.launch("image/*") },
                enabled = subjects.isNotEmpty() && !scanning,
                modifier = Modifier.weight(1f)
            ) { Text(if (scanning) "Scanning…" else "Scan image") }
        }
        if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))

        if (subjects.isEmpty()) {
            EmptyState("Add subjects first (More → Subjects), then build your timetable.")
        } else if (dayEntries.isEmpty()) {
            EmptyState("No classes on ${DAY_NAMES[day - 1]}.")
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(dayEntries, key = { it.id }) { e ->
                val s = subjMap[e.subjectId]
                AttCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ColorDot(Color(s?.color ?: 0xFF888888L))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s?.name ?: "Unknown", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${fmtTime(e.startMin)} – ${fmtTime(e.endMin)}" +
                                    if (e.room.isNotBlank()) " · Room ${e.room}" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                (if (e.isExtra) "Extra class" else "Regular") + if (e.active) "" else " · Inactive",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Switch(checked = e.active, onCheckedChange = { vm.setEntryActive(e, it) })
                    }
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = { editing = e }) { Icon(Icons.Default.Edit, "Edit") }
                        IconButton(onClick = { deleting = e }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }

    if (adding) {
        EntryDialog(
            initial = null,
            subjects = subjects,
            defaultDay = day,
            onSave = {
                vm.saveEntry(it)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }
    editing?.let { e ->
        EntryDialog(
            initial = e,
            subjects = subjects,
            defaultDay = e.dayOfWeek,
            onSave = {
                vm.saveEntry(it)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete class?") },
            text = { Text("This removes it from the timetable and cancels its reminder. Past attendance stays.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteEntry(e)
                    deleting = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
    drafts?.let { d ->
        OcrPreviewDialog(
            drafts = d,
            subjects = subjects,
            onSave = { vm.saveDrafts(it) },
            onDismiss = { vm.discardDrafts() }
        )
    }
}

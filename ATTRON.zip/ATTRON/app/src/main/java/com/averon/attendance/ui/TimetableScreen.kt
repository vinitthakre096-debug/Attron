package com.averon.attendance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.DAY_NAMES
import com.averon.attendance.data.TimetableEntry
import com.averon.attendance.data.TimetableTabCategory
import com.averon.attendance.data.fmtTime
import java.time.LocalDate

@Composable
fun TimetableScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
    onOpenImportScanner: () -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val entries by vm.entries.collectAsState()
    val subjMap = remember(subjects) { subjects.associateBy { it.id } }

    var selectedCategory by remember { mutableStateOf(TimetableTabCategory.REGULAR) }
    var day by remember { mutableIntStateOf(LocalDate.now().dayOfWeek.value) }
    var editing by remember { mutableStateOf<TimetableEntry?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<TimetableEntry?>(null) }

    val filteredEntries = remember(entries, day, selectedCategory) {
        entries.filter {
            it.dayOfWeek == day && it.category == selectedCategory
        }.sortedBy { it.startMin }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Bottom-right botanical leaf sprig matching reference image
        CornerBotanicalLeaves(
            flipHorizontal = true,
            flipVertical = true,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .width(150.dp)
                .height(130.dp)
        )

        Column(modifier = Modifier.fillMaxSize()) {
            // Top bar: <- Timetable + circular green '+' button
            ScreenHeader(
                title = "Timetable",
                onBack = onBack,
                trailing = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onOpenImportScanner) {
                            Icon(
                                imageVector = Icons.Outlined.DocumentScanner,
                                contentDescription = "Scan Timetable",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                                .clickable {
                                    if (subjects.isNotEmpty()) adding = true
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add class",
                                tint = Color.White
                            )
                        }
                    }
                }
            )

            // Segmented Pill Bar: Regular | Temporary | Extra
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp),
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TimetableTabCategory.entries.forEach { cat ->
                        val selected = selectedCategory == cat
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary
                                    else Color.Transparent
                                )
                                .clickable { selectedCategory = cat }
                                .padding(vertical = 9.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cat.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Weekday Selector Row (Mon, Tue [green pill], Wed, Thu, Fri, Sat, Sun)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DAY_NAMES.forEachIndexed { idx, name ->
                    val dayNum = idx + 1
                    val selected = day == dayNum
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary
                                else Color.Transparent
                            )
                            .clickable { day = dayNum }
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Class Cards List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (subjects.isEmpty()) {
                    item {
                        EmptyState("Add your subjects first in More → Subjects, then tap + to schedule classes.")
                    }
                } else if (filteredEntries.isEmpty()) {
                    item {
                        EmptyState("No ${selectedCategory.label.lowercase()} classes scheduled for ${DAY_NAMES[day - 1]}.")
                    }
                    item {
                        OutlinedButton(
                            onClick = onOpenImportScanner,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Outlined.DocumentScanner, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Import Timetable from Camera / Gallery")
                        }
                    }
                }

                items(filteredEntries, key = { it.id }) { e ->
                    val subj = subjMap[e.subjectId]
                    val barColor = Color(subj?.color ?: 0xFF4B8B47L)
                    var menuOpen by remember { mutableStateOf(false) }

                    GlassCard(containerAlpha = 0.94f, cornerRadius = 20.dp) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left vertical colored accent bar matching reference image
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(52.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (e.active) barColor else barColor.copy(alpha = 0.35f))
                            )

                            Spacer(Modifier.width(12.dp))

                            // Circular Subject Icon Badge
                            SubjectIconBadge(subj, size = 44.dp)

                            Spacer(Modifier.width(12.dp))

                            // Subject Short Name, Timing, Room
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = subj?.shortName ?: subj?.name ?: "Class",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (e.active) MaterialTheme.colorScheme.onSurface
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (!e.active) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = "Paused",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "${fmtTime(e.startMin)} – ${fmtTime(e.endMin)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (e.room.isNotBlank()) {
                                    Text(
                                        text = e.room,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Three-Dot Overflow Menu
                            Box {
                                IconButton(onClick = { menuOpen = true }) {
                                    Icon(
                                        imageVector = Icons.Default.MoreVert,
                                        contentDescription = "Class actions",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                DropdownMenu(
                                    expanded = menuOpen,
                                    onDismissRequest = { menuOpen = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Edit class") },
                                        onClick = {
                                            menuOpen = false
                                            editing = e
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(if (e.active) "Deactivate reminder" else "Activate reminder") },
                                        onClick = {
                                            menuOpen = false
                                            vm.setEntryActive(e, !e.active)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                                        onClick = {
                                            menuOpen = false
                                            deleting = e
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        EntryDialog(
            initial = null,
            subjects = subjects,
            defaultDay = day,
            defaultCategory = selectedCategory,
            onSave = {
                vm.saveEntry(it)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }

    editing?.let { e ->
        EntryDialog(
            initial = e,
            subjects = subjects,
            defaultDay = e.dayOfWeek,
            defaultCategory = e.category,
            onSave = {
                vm.saveEntry(it)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }

    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete class?") },
            text = { Text("This removes it from the timetable and cancels its reminder. Past attendance stays.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteEntry(e)
                    deleting = null
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text("Cancel") }
            }
        )
    }
}

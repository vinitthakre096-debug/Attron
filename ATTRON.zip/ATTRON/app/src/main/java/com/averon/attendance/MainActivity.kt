package com.averon.attendance

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.averon.attendance.notify.ReminderScheduler
import com.averon.attendance.ui.AboutAttronScreen
import com.averon.attendance.ui.AttronSplashScreen
import com.averon.attendance.ui.AttronTheme
import com.averon.attendance.ui.BackupRestoreScreen
import com.averon.attendance.ui.CalendarScreen
import com.averon.attendance.ui.ExtraClassesScreen
import com.averon.attendance.ui.HomeScreen
import com.averon.attendance.ui.ImportTimetableScreen
import com.averon.attendance.ui.MainViewModel
import com.averon.attendance.ui.MoreScreen
import com.averon.attendance.ui.OnboardingScreen
import com.averon.attendance.ui.ReportsScreen
import com.averon.attendance.ui.SettingsScreen
import com.averon.attendance.ui.SubjectsScreen
import com.averon.attendance.ui.ThemeScreen
import com.averon.attendance.ui.TimetableScreen
import com.averon.attendance.ui.isDarkTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val app = application as AttronApp
        lifecycleScope.launch(Dispatchers.IO) {
            ReminderScheduler.scheduleAll(applicationContext, app.db.timetableDao().allOnce())
        }

        setContent {
            val vm: MainViewModel = viewModel()
            val settings by vm.settings.collectAsState()
            val dark = isDarkTheme(settings.theme)
            var showSplash by remember { mutableStateOf(true) }

            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(
                        android.graphics.Color.TRANSPARENT,
                        android.graphics.Color.TRANSPARENT
                    ) { dark },
                    navigationBarStyle = SystemBarStyle.auto(
                        android.graphics.Color.TRANSPARENT,
                        android.graphics.Color.TRANSPARENT
                    ) { dark }
                )
                onDispose { }
            }

            AttronTheme(theme = settings.theme, accentColor = settings.accentColor) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    when {
                        showSplash -> AttronSplashScreen(onFinished = { showSplash = false })
                        !settings.onboardingDone -> OnboardingScreen(
                            initialName = settings.userName,
                            initialSubtitle = settings.userSubtitle,
                            onContinue = { name, sub -> vm.completeOnboarding(name, sub) }
                        )
                        else -> AppRoot(vm)
                    }
                }
            }
        }
    }
}

private data class BottomNavItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val bottomNavItems = listOf(
    BottomNavItem("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
    BottomNavItem("calendar", "Calendar", Icons.Filled.CalendarToday, Icons.Outlined.CalendarToday),
    BottomNavItem("reports", "Reports", Icons.Filled.BarChart, Icons.Outlined.BarChart),
    BottomNavItem("more", "More", Icons.Filled.GridView, Icons.Outlined.GridView)
)

@Composable
private fun AppRoot(vm: MainViewModel) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.message.collect { snack.showSnackbar(it) } }

    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route

    fun navigateToRoute(target: String) {
        nav.navigate(target) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp
            ) {
                bottomNavItems.forEach { item ->
                    val selected = when (item.route) {
                        "home" -> route == "home"
                        "calendar" -> route == "calendar" || route == "timetable" || route == "import_timetable"
                        "reports" -> route == "reports"
                        "more" -> route in listOf("more", "subjects", "extra_classes", "settings", "theme", "backup_restore", "about")
                        else -> route == item.route
                    }
                    NavigationBarItem(
                        selected = selected,
                        onClick = { navigateToRoute(item.route) },
                        icon = {
                            Icon(
                                imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.label
                            )
                        },
                        alwaysShowLabel = false,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { pad ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(bottom = pad.calculateBottomPadding())
        ) {
            composable("home") {
                HomeScreen(
                    vm = vm,
                    onNavigateTab = { dest -> navigateToRoute(dest) }
                )
            }
            composable("timetable") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    TimetableScreen(
                        vm = vm,
                        onBack = { nav.popBackStack() },
                        onOpenImportScanner = { nav.navigate("import_timetable") }
                    )
                }
            }
            composable("import_timetable") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    ImportTimetableScreen(
                        vm = vm,
                        onBack = { nav.popBackStack() }
                    )
                }
            }
            composable("calendar") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    CalendarScreen(
                        vm = vm,
                        onBack = { navigateToRoute("home") }
                    )
                }
            }
            composable("reports") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    ReportsScreen(
                        vm = vm,
                        onBack = { navigateToRoute("home") }
                    )
                }
            }
            composable("more") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    MoreScreen(
                        vm = vm,
                        onBack = { navigateToRoute("home") },
                        onSubjects = { nav.navigate("subjects") },
                        onExtraClasses = { nav.navigate("extra_classes") },
                        onReminders = { nav.navigate("settings") },
                        onTheme = { nav.navigate("theme") },
                        onBackupRestore = { nav.navigate("backup_restore") },
                        onAbout = { nav.navigate("about") }
                    )
                }
            }
            composable("subjects") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    SubjectsScreen(vm = vm, onBack = { nav.popBackStack() })
                }
            }
            composable("extra_classes") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    ExtraClassesScreen(vm = vm, onBack = { nav.popBackStack() })
                }
            }
            composable("settings") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    SettingsScreen(vm = vm, onBack = { nav.popBackStack() })
                }
            }
            composable("theme") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    ThemeScreen(vm = vm, onBack = { nav.popBackStack() })
                }
            }
            composable("backup_restore") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    BackupRestoreScreen(vm = vm, onBack = { nav.popBackStack() })
                }
            }
            composable("about") {
                Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                    AboutAttronScreen(onBack = { nav.popBackStack() })
                }
            }
        }
    }
}

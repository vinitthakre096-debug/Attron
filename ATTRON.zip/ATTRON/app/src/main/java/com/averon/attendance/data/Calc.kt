package com.averon.attendance.data

import kotlin.math.ceil
import kotlin.math.floor

/**
 * Attendance % = Present / (Present + Absent) * 100.
 * Off classes are excluded from both numerator and denominator.
 */
data class Stats(val present: Int, val absent: Int) {
    val total: Int get() = present + absent
    val percent: Double get() = if (total == 0) 0.0 else present * 100.0 / total
}

fun List<AttendanceRecord>.stats(): Stats =
    Stats(count { it.status == Status.PRESENT }, count { it.status == Status.ABSENT })

/** Consecutive classes that must be attended to reach [target]%. Null if impossible. */
fun classesNeeded(s: Stats, target: Int): Int? {
    if (s.total == 0) return 0
    if (s.percent >= target) return 0
    if (target >= 100) return null
    val n = ceil((target * s.total - 100.0 * s.present) / (100 - target) - 1e-9).toInt()
    return n.coerceAtLeast(1)
}

/** Classes that can still be missed while staying at or above [target]%. */
fun classesCanMiss(s: Stats, target: Int): Int {
    if (s.total == 0 || target <= 0) return 0
    if (s.percent < target) return 0
    return floor(100.0 * s.present / target - s.total + 1e-9).toInt().coerceAtLeast(0)
}

fun shortageText(s: Stats, target: Int): String {
    if (s.total == 0) return "No classes recorded yet"
    return if (s.percent >= target) {
        val m = classesCanMiss(s, target)
        if (m == 0) "On target. Don't miss the next class"
        else "You can miss $m more class${if (m == 1) "" else "es"} and stay at $target%"
    } else {
        val n = classesNeeded(s, target)
        if (n == null) "Target $target% can't be reached"
        else "Attend $n class${if (n == 1) "" else "es"} in a row to reach $target%"
    }
}

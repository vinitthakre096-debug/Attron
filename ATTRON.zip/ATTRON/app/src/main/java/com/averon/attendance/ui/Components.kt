package com.averon.attendance.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.ClassType
import com.averon.attendance.data.Status
import com.averon.attendance.data.Subject
import com.averon.attendance.data.fmtDate
import com.averon.attendance.data.fmtTime
import java.time.LocalDate

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    containerAlpha: Float = 0.88f,
    cornerRadius: Dp = 22.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val surfaceColor = MaterialTheme.colorScheme.surface.copy(alpha = containerAlpha)
    val borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    val shape = RoundedCornerShape(cornerRadius)
    val colors = CardDefaults.cardColors(containerColor = surfaceColor)
    val elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    val border = BorderStroke(1.dp, borderColor)

    if (onClick == null) {
        Card(
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            colors = colors,
            elevation = elevation,
            border = border
        ) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(
            onClick = onClick,
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            colors = colors,
            elevation = elevation,
            border = border
        ) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun AttCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    GlassCard(modifier = modifier, onClick = onClick, content = content)
}

@Composable
fun ReferenceAttendanceRing(
    percent: Float,
    label: String,
    subLabel: String = "Attendance",
    diameter: Dp = 114.dp,
    modifier: Modifier = Modifier
) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val primary = MaterialTheme.colorScheme.primary
    val secondaryLight = primary.copy(alpha = 0.55f)

    Box(contentAlignment = Alignment.Center, modifier = modifier.size(diameter)) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = diameter.toPx() * 0.095f
            val arcSize = Size(size.width - sw, size.height - sw)
            val topLeft = Offset(sw / 2, sw / 2)
            drawArc(track, 0f, 360f, false, topLeft, arcSize, style = Stroke(sw, cap = StrokeCap.Round))
            val sweep = 360f * (percent.coerceIn(0f, 100f) / 100f)
            if (sweep > 0f) {
                drawArc(
                    secondaryLight,
                    -90f,
                    sweep,
                    false,
                    topLeft,
                    arcSize,
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
                drawArc(
                    primary,
                    -90f,
                    sweep * 0.72f,
                    false,
                    topLeft,
                    arcSize,
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Text(
                text = subLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SubjectIconBadge(
    subject: Subject?,
    size: Dp = 42.dp
) {
    val accent = Color(subject?.color ?: 0xFF4B8B47L)
    val code = (subject?.shortName ?: subject?.name ?: "").uppercase()
    val icon: ImageVector = when {
        code.contains("BEE") || code.contains("ELEC") -> Icons.Outlined.Bolt
        code.contains("DLD") || code.contains("DIG") || code.contains("MICRO") -> Icons.Outlined.Memory
        code.contains("CP") || code.contains("PROG") || code.contains("CS") || code.contains("CODE") -> Icons.Outlined.Code
        code.contains("MDC") || code.contains("MATH") || code.contains("BOOK") -> Icons.AutoMirrored.Outlined.MenuBook
        else -> Icons.Outlined.School
    }

    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(accent.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(size * 0.52f)
        )
    }
}

@Composable
fun StatusChip(status: Status) {
    val c = statusColor(status)
    Surface(color = c.copy(alpha = 0.15f), shape = RoundedCornerShape(50)) {
        Text(
            status.label,
            color = c,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ColorDot(color: Color, diameter: Dp = 10.dp) {
    Box(
        Modifier
            .size(diameter)
            .clip(CircleShape)
            .background(color)
    )
}

@Composable
fun PageTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.headlineSmall,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(top = 6.dp)
    )
}

@Composable
fun EmptyState(text: String) {
    GlassCard {
        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
            Text(
                text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ScreenHeader(
    title: String,
    onBack: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.weight(1f)
        )
        if (trailing != null) {
            trailing()
        }
    }
}

@Composable
fun <T> DropdownField(
    label: String,
    items: List<T>,
    selected: T?,
    text: (T) -> String,
    modifier: Modifier = Modifier,
    onSelect: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(selected?.let(text) ?: label, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { item ->
                DropdownMenuItem(
                    text = { Text(text(item)) },
                    onClick = {
                        open = false
                        onSelect(item)
                    }
                )
            }
        }
    }
}

fun pickTime(ctx: Context, initialMin: Int, onPicked: (Int) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> onPicked(h * 60 + m) }, initialMin / 60, initialMin % 60, false).show()
}

fun pickDate(ctx: Context, epochDay: Long, onPicked: (Long) -> Unit) {
    val d = LocalDate.ofEpochDay(epochDay)
    DatePickerDialog(
        ctx,
        { _, y, m, day -> onPicked(LocalDate.of(y, m + 1, day).toEpochDay()) },
        d.year,
        d.monthValue - 1,
        d.dayOfMonth
    ).show()
}

@Composable
fun RecordRow(r: AttendanceRecord, subjects: Map<Long, Subject>, onClick: (() -> Unit)? = null) {
    val s = subjects[r.subjectId]
    GlassCard(onClick = onClick, cornerRadius = 18.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SubjectIconBadge(s, size = 38.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s?.shortName ?: "?", style = MaterialTheme.typography.titleMedium)
                Text(
                    "${fmtDate(r.date)} · ${fmtTime(r.startMin)} – ${fmtTime(r.endMin)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (r.type == ClassType.REPLACEMENT) {
                    val orig = subjects[r.scheduledSubjectId ?: -1L]
                    Text(
                        "Instead of ${orig?.shortName ?: "scheduled class"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                StatusChip(r.status)
                Text(
                    r.type.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

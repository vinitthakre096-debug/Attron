package com.averon.attendance.data

class Repo(val db: AppDatabase) {

    /** Mark a regular (timetable) class for a given date. Replaces any existing record for that class+date. */
    suspend fun mark(entry: TimetableEntry, epochDay: Long, status: Status) {
        db.attendanceDao().upsert(
            AttendanceRecord(
                subjectId = entry.subjectId,
                date = epochDay,
                startMin = entry.startMin,
                endMin = entry.endMin,
                status = status,
                type = if (entry.isExtra) ClassType.EXTRA else ClassType.REGULAR,
                timetableEntryId = entry.id,
                room = entry.room
            )
        )
    }

    /** A different subject was taught instead of the scheduled one. Attendance counts for the actual subject only. */
    suspend fun replace(entry: TimetableEntry, epochDay: Long, actualSubjectId: Long, status: Status) {
        db.attendanceDao().upsert(
            AttendanceRecord(
                subjectId = actualSubjectId,
                date = epochDay,
                startMin = entry.startMin,
                endMin = entry.endMin,
                status = status,
                type = ClassType.REPLACEMENT,
                timetableEntryId = entry.id,
                scheduledSubjectId = entry.subjectId,
                room = entry.room
            )
        )
    }

    /** A one-off class outside the timetable. */
    suspend fun extra(
        subjectId: Long,
        epochDay: Long,
        startMin: Int,
        endMin: Int,
        room: String,
        status: Status
    ) {
        db.attendanceDao().upsert(
            AttendanceRecord(
                subjectId = subjectId,
                date = epochDay,
                startMin = startMin,
                endMin = endMin,
                status = status,
                type = ClassType.EXTRA,
                room = room
            )
        )
    }
}

package com.averon.attendance.data

class Repo(val db: AppDatabase) {

    suspend fun mark(entry: TimetableEntry, epochDay: Long, status: Status) {
        val type = when {
            entry.isTemporary -> ClassType.TEMPORARY
            entry.isExtra -> ClassType.EXTRA
            else -> ClassType.REGULAR
        }
        db.attendanceDao().upsert(
            AttendanceRecord(
                subjectId = entry.subjectId,
                date = epochDay,
                startMin = entry.startMin,
                endMin = entry.endMin,
                status = status,
                type = type,
                timetableEntryId = entry.id,
                room = entry.room
            )
        )
    }

    suspend fun replace(entry: TimetableEntry, epochDay: Long, actualSubjectId: Long, status: Status) {
        db.attendanceDao().upsert(
            AttendanceRecord(
                subjectId = actualSubjectId,
                date = epochDay,
                startMin = entry.startMin,
                endMin = entry.endMin,
                status = status,
                type = ClassType.REPLACEMENT,
                timetableEntryId = entry.id,
                scheduledSubjectId = entry.subjectId,
                room = entry.room
            )
        )
    }

    suspend fun extra(
        subjectId: Long,
        epochDay: Long,
        startMin: Int,
        endMin: Int,
        room: String,
        status: Status
    ) {
        db.attendanceDao().upsert(
            AttendanceRecord(
                subjectId = subjectId,
                date = epochDay,
                startMin = startMin,
                endMin = endMin,
                status = status,
                type = ClassType.EXTRA,
                room = room
            )
        )
    }
}

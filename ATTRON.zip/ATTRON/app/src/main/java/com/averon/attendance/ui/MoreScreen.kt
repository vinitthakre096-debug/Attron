package com.averon.attendance.ui

import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import com.averon.attendance.R
import com.averon.attendance.data.ACCENT_PALETTE
import com.averon.attendance.data.AppTheme
import com.averon.attendance.data.AppBackground
import com.averon.attendance.data.ClassType
import java.time.LocalDate
import kotlin.math.roundToInt

@Composable
fun MoreScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
    onSubjects: () -> Unit,
    onExtraClasses: () -> Unit,
    onReminders: () -> Unit,
    onTheme: () -> Unit,
    onBackupRestore: () -> Unit,
    onAbout: () -> Unit
) {
    val settings by vm.settings.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        // Top-right hanging botanical leaves matching Reference Screen #9
        CornerBotanicalLeaves(
            flipHorizontal = true,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .width(175.dp)
                .height(155.dp)
        )

        Column(modifier = Modifier.fillMaxSize()) {
            ScreenHeader(title = "More", onBack = onBack)

            Spacer(Modifier.height(6.dp))

            Box(modifier = Modifier.padding(horizontal = 18.dp)) {
                GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                    MoreMenuRow(
                        icon = Icons.AutoMirrored.Outlined.MenuBook,
                        title = "Subjects",
                        onClick = onSubjects
                    )
                    MoreDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.EventAvailable,
                        title = "Extra Classes",
                        onClick = onExtraClasses
                    )
                    MoreDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.NotificationsNone,
                        title = "Reminders",
                        onClick = onReminders
                    )
                    MoreDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.Palette,
                        title = "Themes & Backgrounds",
                        trailingText = "${settings.theme.label} · ${settings.background.label}",
                        onClick = onTheme
                    )
                    MoreDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.History,
                        title = "Backup & Restore",
                        onClick = onBackupRestore
                    )
                    MoreDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.Info,
                        title = "About ATTRON",
                        onClick = onAbout
                    )
                }
            }
        }
    }
}

@Composable
private fun MoreMenuRow(
    icon: ImageVector,
    title: String,
    trailingText: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(21.dp)
        )
        Spacer(Modifier.width(14.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (trailingText != null) {
            Text(
                text = trailingText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(6.dp))
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun MoreDivider() {
    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
}

// ==========================================
// THEME + BACKGROUND GALLERY
// ==========================================
@Composable
fun ThemeScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    val settings by vm.settings.collectAsState()
    var pendingTheme by remember(settings.theme) { mutableStateOf(settings.theme) }
    var pendingBackground by remember(settings.background) { mutableStateOf(settings.background) }
    val ctx = LocalContext.current



    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Themes & Backgrounds", onBack = onBack)
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("App Theme", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Choose the colours used across ATTRON.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            AppTheme.entries.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { theme ->
                        val (swatch, surface, ink) = when (theme) {
                            AppTheme.BREEZE -> Triple(Color(0xFF6D9B68), Color(0xFFF7F5EE), Color(0xFF253126))
                            AppTheme.MIDNIGHT -> Triple(Color(0xFF56B99B), Color(0xFF101B20), Color(0xFFEAF2F2))
                            AppTheme.LAVENDER -> Triple(Color(0xFF987CC1), Color(0xFFF7F3FC), Color(0xFF292333))
                            AppTheme.MOCHA -> Triple(Color(0xFF947052), Color(0xFFF7F1E9), Color(0xFF33271F))
                            AppTheme.ARCTIC -> Triple(Color(0xFF397EAD), Color(0xFFF0F7FC), Color(0xFF1B2B38))
                            AppTheme.ROSE -> Triple(Color(0xFFB66F88), Color(0xFFFCF3F6), Color(0xFF35232B))
                        }
                        Surface(
                            modifier = Modifier.weight(1f).height(112.dp).clickable { pendingTheme = theme },
                            shape = RoundedCornerShape(18.dp), color = surface,
                            border = BorderStroke(if (pendingTheme == theme) 2.dp else 1.dp, if (pendingTheme == theme) swatch else MaterialTheme.colorScheme.outline.copy(alpha=.4f))
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(28.dp).clip(CircleShape).background(swatch))
                                    Spacer(Modifier.width(8.dp))
                                    Text(theme.label, color = ink, fontWeight = FontWeight.Bold)
                                }
                                Text(theme.subtitle, color = ink.copy(alpha=.72f), style = MaterialTheme.typography.labelSmall)
                                if (pendingTheme == theme) Text("Preview selected", color = swatch, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Button(onClick = { vm.setTheme(pendingTheme) }, enabled = pendingTheme != settings.theme, modifier = Modifier.fillMaxWidth()) {
                Text(if (pendingTheme == settings.theme) "Theme Applied" else "Apply ${pendingTheme.label} Theme")
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha=.35f))
            Text("Background Gallery", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Backgrounds are independent of your app theme. Preview first, then apply.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            AppBackground.entries.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { bg ->
                        val selected = pendingBackground == bg
                        Surface(
                            modifier = Modifier.weight(1f).clickable { pendingBackground = bg },
                            shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha=.35f))
                        ) {
                            Column {
                                AttronBackground(
                                    background = bg,
                                    theme = pendingTheme,
                                    modifier = Modifier.fillMaxWidth().height(112.dp)
                                )
                                Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(bg.label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    if (selected) Icon(Icons.Default.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Preview · ${pendingBackground.label}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    AttronBackground(
                        background = pendingBackground,
                        theme = pendingTheme,
                        modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(14.dp))
                    )
                    Text("This background will be used on the Home screen. Your selected theme stays unchanged.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Button(onClick = { vm.setBackground(pendingBackground) }, enabled = pendingBackground != settings.background, modifier = Modifier.fillMaxWidth()) {
                Text(if (pendingBackground == settings.background) "Background Applied" else "Apply ${pendingBackground.label}")
            }
            OutlinedButton(onClick = { pendingBackground = AppBackground.MOUNTAIN; vm.setBackground(AppBackground.MOUNTAIN) }, modifier = Modifier.fillMaxWidth()) {
                Text("Reset to Original Mountain")
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

// ==========================================
// EXTRA CLASSES SCREEN (Dedicated view from More -> Extra Classes)
// ==========================================
@Composable
fun ExtraClassesScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val subjMap = remember(subjects) { subjects.associateBy { it.id } }
    val extraRecords = remember(records) { records.filter { it.type == ClassType.EXTRA } }

    var showAddExtra by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Extra Classes", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Button(
                    onClick = { showAddExtra = true },
                    enabled = subjects.isNotEmpty(),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("+ Record Extra Class")
                }
            }

            if (extraRecords.isEmpty()) {
                item {
                    EmptyState("No extra classes recorded yet. Extra classes count toward the selected subject's attendance.")
                }
            } else {
                items(extraRecords, key = { it.id }) { r ->
                    RecordRow(r, subjMap)
                }
            }
        }
    }

    if (showAddExtra) {
        ExtraClassDialog(
            subjects = subjects,
            defaultDate = LocalDate.now().toEpochDay(),
            onSave = { sid, d, s, e, room, st ->
                vm.addExtra(sid, d, s, e, room, st)
                showAddExtra = false
            },
            onDismiss = { showAddExtra = false }
        )
    }
}

// ==========================================
// REMINDERS & TARGET SETTINGS SCREEN
// ==========================================
@Composable
fun SettingsScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val settings by vm.settings.collectAsState()
    var target by remember(settings.target) { mutableFloatStateOf(settings.target.toFloat()) }

    fun hasExactAlarmAccess(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    var exactOk by remember { mutableStateOf(hasExactAlarmAccess()) }
    LaunchedEffect(Unit) {
        while (true) {
            exactOk = hasExactAlarmAccess()
            delay(1_000L)
        }
    }
    LaunchedEffect(exactOk) {
        if (exactOk) vm.rescheduleReminders()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Reminders & Target", onBack = onBack)

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                GlassCard(containerAlpha = 0.94f, cornerRadius = 20.dp) {
                    Text(
                        text = "Attendance Target: ${target.roundToInt()}%",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Slider(
                        value = target,
                        onValueChange = { target = it },
                        onValueChangeFinished = { vm.setTarget(target.roundToInt()) },
                        valueRange = 50f..100f,
                        steps = 49
                    )
                    Text(
                        text = "Used for shortage warnings and safe-bunk calculations.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                GlassCard(containerAlpha = 0.94f, cornerRadius = 20.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = "Lecture-end reminders",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Direct Present / Absent / Off action buttons in notification",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.notifications,
                            onCheckedChange = { vm.setNotifications(it) }
                        )
                    }

                    Spacer(Modifier.height(10.dp))

                    if (!exactOk) {
                        Text(
                            text = "Exact alarms are off. Android may delay reminders (sometimes by a few minutes). Enable exact alarms for on-time lecture reminders.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                        .setData(Uri.parse("package:${ctx.packageName}"))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Allow exact alarms") }
                        Spacer(Modifier.height(6.dp))
                    }

                    OutlinedButton(
                        onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        },
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Battery optimisation settings") }

                    Text(
                        text = "Android battery optimisation or force-stopping the app can delay or block background reminders.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}

// ==========================================
// BACKUP & RESTORE SCREEN
// ==========================================
@Composable
fun BackupRestoreScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }

    val exporter = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) vm.exportTo(uri)
    }

    val importer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) pendingRestore = uri
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Backup & Restore", onBack = onBack)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                Icon(
                    imageVector = Icons.Outlined.Backup,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Offline JSON Backup",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Export all your subjects, weekly timetable, and attendance history into a portable JSON file. Back up before uninstalling ATTRON.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { exporter.launch("attron-backup-${LocalDate.now()}.json") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("Export JSON Backup")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { importer.launch(arrayOf("application/json", "text/*", "*/*")) },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("Restore from JSON File")
                }
            }
        }
    }

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore backup?") },
            text = {
                Text("This replaces ALL current subjects, timetable, and attendance records with the backup file. Invalid files are rejected safely.")
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.importFrom(uri)
                    pendingRestore = null
                }) { Text("Restore") }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestore = null }) { Text("Cancel") }
            }
        )
    }
}

// ==========================================
// ABOUT ATTRON SCREEN
// ==========================================
@Composable
fun AboutAttronScreen(onBack: () -> Unit) {
    val features = listOf(
        "Smart Attendance" to "Track every lecture with quick Present, Absent and Off actions.",
        "Timetable & Reminders" to "Keep your weekly schedule organized and get lecture-end reminders.",
        "Replacement & Extra Classes" to "Record the subject actually taught and manage additional lectures.",
        "Attendance Insights" to "Review overall, subject-wise and monthly attendance reports.",
        "Offline-First Privacy" to "Your subjects, schedules and attendance stay stored on this device."
    )

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "About ATTRON", onBack = onBack)
        androidx.compose.foundation.lazy.LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AttronLeafLogo(size = 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Why ATTRON?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("Your college life, organized.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    features.forEach { (title, description) ->
                        Row(modifier = Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp).size(20.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(containerAlpha = 0.94f, cornerRadius = 20.dp) {
                    Text("Designed & developed by", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Text("Vinit Thakre", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                    Text("ATTRON v2.0 · Offline-First College Companion", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                GlassCard(containerAlpha = 0.96f, cornerRadius = 20.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(8.dp))
                        Text("Before you uninstall ATTRON", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Create a Backup & Restore file before uninstalling. Uninstalling the app may permanently delete attendance data stored on this device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

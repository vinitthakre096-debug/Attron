package com.averon.attendance.ui

import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AppTheme
import java.time.LocalDate
import kotlin.math.roundToInt

@Composable
fun MoreScreen(vm: MainViewModel, onSubjects: () -> Unit, onSettings: () -> Unit) {
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestore = uri
    }

    Column(Modifier.fillMaxSize()) {
        PageTitle("More")
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { MoreRow("Subjects", "Add, edit and review subjects", onSubjects) }
            item { MoreRow("Settings", "Theme, attendance target, reminders", onSettings) }
            item {
                MoreRow("Backup", "Save subjects, timetable and attendance as a JSON file") {
                    exporter.launch("attron-backup-${LocalDate.now()}.json")
                }
            }
            item {
                MoreRow("Restore", "Replace current data with a backup file") {
                    importer.launch(arrayOf("application/json", "text/*", "*/*"))
                }
            }
            item {
                AttCard {
                    Text("About ATTRON", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Version 1.0 · Offline-first attendance manager. Your data stays on this device. " +
                            "Back up before uninstalling if you want to keep it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore backup?") },
            text = { Text("This replaces ALL current subjects, timetable and attendance with the contents of the backup file. Invalid files are rejected and nothing changes.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.importFrom(uri)
                    pendingRestore = null
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun MoreRow(title: String, subtitle: String, onClick: () -> Unit) {
    AttCard(onClick = onClick) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val settings by vm.settings.collectAsState()
    var target by remember(settings.target) { mutableFloatStateOf(settings.target.toFloat()) }

    val exactOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Settings", onBack)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AttCard {
                    Text("Theme", style = MaterialTheme.typography.titleMedium)
                    AppTheme.entries.forEach { t ->
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = settings.theme == t, onClick = { vm.setTheme(t) })
                            Text(t.label)
                        }
                    }
                }
            }
            item {
                AttCard {
                    Text("Attendance target: ${target.roundToInt()}%", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = target,
                        onValueChange = { target = it },
                        onValueChangeFinished = { vm.setTarget(target.roundToInt()) },
                        valueRange = 50f..100f,
                        steps = 49
                    )
                    Text(
                        "Used for shortage warnings and the 'classes to attend / can miss' calculator.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item {
                AttCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Lecture-end reminders", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Notification with Present / Absent / Off buttons",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = settings.notifications, onCheckedChange = { vm.setNotifications(it) })
                    }
                    Spacer(Modifier.height(8.dp))
                    if (!exactOk) {
                        Text(
                            "Exact alarms are off, so reminders may arrive a few minutes late.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        OutlinedButton(onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                    .setData(Uri.parse("package:${ctx.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }) { Text("Allow exact alarms") }
                    }
                    OutlinedButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text("Battery settings") }
                    Text(
                        "Android battery optimisation or force-stopping the app can delay or block reminders. " +
                            "Reminders cannot be guaranteed after a force-stop.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}

package com.averon.attendance.notify

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.averon.attendance.AttronApp
import com.averon.attendance.MainActivity
import com.averon.attendance.R
import com.averon.attendance.data.Status
import com.averon.attendance.data.Subject
import com.averon.attendance.data.TimetableEntry
import com.averon.attendance.data.fmtTime

object NotificationHelper {

    fun notifId(entryId: Long, epochDay: Long): Int = (entryId * 1000 + (epochDay % 1000)).toInt()

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, entry: TimetableEntry, subject: Subject, epochDay: Long) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val nid = notifId(entry.id, epochDay)

        fun action(label: String, status: Status, idx: Int): NotificationCompat.Action {
            val i = Intent(ctx, ActionReceiver::class.java)
                .setAction("attron.MARK.${status.name}.$nid")
                .putExtra("entryId", entry.id)
                .putExtra("epochDay", epochDay)
                .putExtra("status", status.name)
                .putExtra("nid", nid)
            val pi = PendingIntent.getBroadcast(
                ctx,
                nid * 3 + idx,
                i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            return NotificationCompat.Action.Builder(0, label, pi).build()
        }

        val open = PendingIntent.getActivity(
            ctx,
            nid * 3 + 3,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val timeAndRoom = "${fmtTime(entry.startMin)} – ${fmtTime(entry.endMin)}" +
            if (entry.room.isNotBlank()) " · ${entry.room}" else ""

        val n = NotificationCompat.Builder(ctx, AttronApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("${subject.shortName} Lecture Completed")
            .setContentText(timeAndRoom)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(action("Present", Status.PRESENT, 0))
            .addAction(action("Absent", Status.ABSENT, 1))
            .addAction(action("Off", Status.OFF, 2))
            .build()

        nm.notify(nid, n)
    }
}

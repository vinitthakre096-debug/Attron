package com.averon.attendance.notify

object NotificationHelper {
    fun scheduleAll(context: android.content.Context) {}
}

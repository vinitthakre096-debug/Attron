package com.averon.attendance.notify

object ReminderScheduler {
    fun scheduleAll(context: android.content.Context) {}
}

package com.averon.attendance.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.averon.attendance.data.TimetableEntry
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Schedules one alarm per timetable entry (at the lecture end time).
 * The same PendingIntent (same request code) is reused per entry, so re-scheduling replaces
 * the old alarm and never creates duplicates.
 *
 * Android may delay or drop alarms because of battery optimisation or force-stop.
 */
object ReminderScheduler {

    private fun pending(ctx: Context, entryId: Long): PendingIntent {
        val intent = Intent(ctx, ReminderReceiver::class.java).putExtra("entryId", entryId)
        return PendingIntent.getBroadcast(
            ctx,
            entryId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTriggerMillis(e: TimetableEntry): Long {
        val zone = ZoneId.systemDefault()
        val now = LocalDateTime.now(zone)
        var d = LocalDate.now(zone)
        for (i in 0..7) {
            if (d.dayOfWeek.value == e.dayOfWeek) {
                val c = d.atTime(e.endMin / 60, e.endMin % 60)
                if (c.isAfter(now)) return c.atZone(zone).toInstant().toEpochMilli()
            }
            d = d.plusDays(1)
        }
        return now.plusDays(7).atZone(zone).toInstant().toEpochMilli()
    }

    fun schedule(ctx: Context, e: TimetableEntry) {
        if (!e.active) {
            cancel(ctx, e.id)
            return
        }
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, e.id)
        val at = nextTriggerMillis(e)
        val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun scheduleAll(ctx: Context, entries: List<TimetableEntry>) {
        entries.forEach { schedule(ctx, it) }
    }

    fun cancel(ctx: Context, entryId: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, entryId)
        am.cancel(pi)
        pi.cancel()
    }
}

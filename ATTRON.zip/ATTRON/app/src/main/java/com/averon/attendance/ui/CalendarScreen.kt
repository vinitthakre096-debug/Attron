package com.averon.attendance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Loop
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.DAY_NAMES
import com.averon.attendance.data.Status
import com.averon.attendance.data.fmtTime
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun CalendarScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val entries by vm.entries.collectAsState()
    val records by vm.records.collectAsState()
    val subjMap = remember(subjects) { subjects.associateBy { it.id } }

    var selectedEpochDay by rememberSaveable { mutableStateOf(LocalDate.now().toEpochDay()) }
    var monthKey by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    val selectedDate = remember(selectedEpochDay) { LocalDate.ofEpochDay(selectedEpochDay) }
    val currentMonth = remember(monthKey) { YearMonth.parse(monthKey) }
    fun changeMonth(delta: Long) { monthKey = currentMonth.plusMonths(delta).toString() }

    val monthFormatter = remember { DateTimeFormatter.ofPattern("MMM yyyy") }
    val selectedHeaderFormatter = remember { DateTimeFormatter.ofPattern("d MMM") }

    val recordsByEpoch = remember(records) { records.groupBy { it.date } }

    val selectedEpoch = selectedDate.toEpochDay()
    val selectedDow = selectedDate.dayOfWeek.value
    val dayTimetable = remember(entries, selectedDow) {
        entries.filter { it.active && it.dayOfWeek == selectedDow }.sortedBy { it.startMin }
    }
    val dayRecords = remember(recordsByEpoch, selectedEpoch) {
        recordsByEpoch[selectedEpoch].orEmpty()
    }

    // Build calendar cells (Sunday = 0 .. Saturday = 6)
    val firstOfMonth = currentMonth.atDay(1)
    val startOffset = firstOfMonth.dayOfWeek.value % 7 // Sun=0, Mon=1..Sat=6
    val daysInMonth = currentMonth.lengthOfMonth()
    val totalCells = ((startOffset + daysInMonth + 6) / 7) * 7

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Calendar", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Month Navigator Row: <  Nov 2026  >
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { changeMonth(-1) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Previous Month"
                        )
                    }
                    Text(
                        text = currentMonth.format(monthFormatter),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { changeMonth(1) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Next Month"
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))

                // Weekday Header (Sun Mon Tue Wed Thu Fri Sat)
                val weekHeaders = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                Row(modifier = Modifier.fillMaxWidth()) {
                    weekHeaders.forEach { h ->
                        Text(
                            text = h,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Calendar Grid
                var horizontalDrag by remember { mutableStateOf(0f) }
                Column(
                    modifier = Modifier.pointerInput(currentMonth) {
                        detectHorizontalDragGestures(
                            onHorizontalDrag = { _, dragAmount -> horizontalDrag += dragAmount },
                            onDragEnd = {
                                if (horizontalDrag > 55f) changeMonth(-1)
                                else if (horizontalDrag < -55f) changeMonth(1)
                                horizontalDrag = 0f
                            },
                            onDragCancel = { horizontalDrag = 0f }
                        )
                    },
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (row in 0 until (totalCells / 7)) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (col in 0 until 7) {
                                val cellIndex = row * 7 + col
                                val dayNum = cellIndex - startOffset + 1
                                if (dayNum in 1..daysInMonth) {
                                    val cellDate = currentMonth.atDay(dayNum)
                                    val cellEpoch = cellDate.toEpochDay()
                                    val isSelected = cellDate == selectedDate
                                    val cellRecords = recordsByEpoch[cellEpoch].orEmpty()
                                    val hasPresent = cellRecords.any { it.status == Status.PRESENT }
                                    val hasAbsent = cellRecords.any { it.status == Status.ABSENT }

                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .clip(CircleShape)
                                            .clickable { selectedEpochDay = cellDate.toEpochDay() },
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isSelected) MaterialTheme.colorScheme.primary
                                                    else Color.Transparent
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = dayNum.toString(),
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                                            )
                                        }
                                        // Attendance indicator dots under date
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(3.dp),
                                            modifier = Modifier.height(6.dp)
                                        ) {
                                            if (hasPresent) {
                                                ColorDot(statusColor(Status.PRESENT), diameter = 4.dp)
                                            }
                                            if (hasAbsent) {
                                                ColorDot(statusColor(Status.ABSENT), diameter = 4.dp)
                                            }
                                        }
                                    }
                                } else {
                                    Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                                }
                            }
                        }
                    }
                }
            }

            // Selected Date Details Glass Card ("14 Nov · Tue    3 Classes")
            item {
                val totalClassesCount = maxOf(dayTimetable.size, dayRecords.size)
                GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${selectedDate.format(selectedHeaderFormatter)} · ${DAY_NAMES[selectedDow - 1]}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$totalClassesCount Class${if (totalClassesCount == 1) "" else "es"}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                    Spacer(Modifier.height(10.dp))

                    if (dayTimetable.isEmpty() && dayRecords.isEmpty()) {
                        Text(
                            text = "No classes scheduled or recorded on this date.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            dayTimetable.forEach { entry ->
                                val rec = dayRecords.firstOrNull { it.timetableEntryId == entry.id }
                                val displaySubjId = rec?.subjectId ?: entry.subjectId
                                val subj = subjMap[displaySubjId]
                                val accent = Color(subj?.color ?: 0xFF4B8B47L)

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val nextStatus = when (rec?.status) {
                                                null -> Status.PRESENT
                                                Status.PRESENT -> Status.ABSENT
                                                Status.ABSENT -> Status.OFF
                                                Status.OFF -> Status.PRESENT
                                            }
                                            vm.mark(entry, selectedEpoch, nextStatus)
                                        },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Loop,
                                        contentDescription = null,
                                        tint = accent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = subj?.shortName ?: subj?.name ?: "Class",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${fmtTime(entry.startMin)} – ${fmtTime(entry.endMin)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Right circular attendance status indicator matching reference
                                    CalendarStatusCircle(status = rec?.status)
                                }
                            }

                            // Any extra/unlinked records for this date
                            val unlinked = dayRecords.filter { r ->
                                dayTimetable.none { it.id == r.timetableEntryId }
                            }
                            unlinked.forEach { rec ->
                                val subj = subjMap[rec.subjectId]
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Loop,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${subj?.shortName ?: "Class"} (${rec.type.label})",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${fmtTime(rec.startMin)} – ${fmtTime(rec.endMin)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    CalendarStatusCircle(status = rec.status)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarStatusCircle(status: Status?) {
    when (status) {
        Status.PRESENT -> {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(statusColor(Status.PRESENT)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Present",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Status.ABSENT -> {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(statusColor(Status.ABSENT)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Absent",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        else -> {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
            )
        }
    }
}

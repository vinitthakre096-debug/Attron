package com.averon.attendance.notify

object ActionReceiver {
    fun scheduleAll(context: android.content.Context) {}
}

package com.averon.attendance.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.averon.attendance.AttronApp
import com.averon.attendance.data.Status
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Handles the Present / Absent / Off buttons on the notification, without opening the app. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val entryId = intent.getLongExtra("entryId", -1L)
        val epochDay = intent.getLongExtra("epochDay", -1L)
        val nid = intent.getIntExtra("nid", 0)
        val status = runCatching { Status.valueOf(intent.getStringExtra("status") ?: "") }.getOrNull()
        if (entryId < 0 || epochDay < 0 || status == null) return

        val app = context.applicationContext as AttronApp
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val entry = app.db.timetableDao().get(entryId)
                if (entry != null) app.repo.mark(entry, epochDay, status)
                NotificationManagerCompat.from(context).cancel(nid)
            } finally {
                pending.finish()
            }
        }
    }
}

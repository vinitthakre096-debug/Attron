package com.averon.attendance.ocr

import android.content.Context
import android.net.Uri
import com.averon.attendance.data.Subject
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class DraftEntry(
    val day: Int,
    val subjectId: Long?,
    val label: String,
    val startMin: Int,
    val endMin: Int,
    val room: String = ""
)

object TimetableOcr {

    private val timeRx = Regex(
        """(\d{1,2})[:.](\d{2})\s*(am|pm)?\s*(?:-|–|—|to)\s*(\d{1,2})[:.](\d{2})\s*(am|pm)?""",
        RegexOption.IGNORE_CASE
    )
    private val roomRx = Regex("""(?:Room|Lab|Hall|[A-Z]-\d{2,4})\s*[\w-]*""", RegexOption.IGNORE_CASE)
    private val dayKeys = listOf("mon", "tue", "wed", "thu", "fri", "sat", "sun")

    suspend fun scan(ctx: Context, uri: Uri, subjects: List<Subject>): List<DraftEntry> {
        val image = InputImage.fromFilePath(ctx, uri)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val text = suspendCancellableCoroutine<Text> { cont ->
                recognizer.process(image)
                    .addOnSuccessListener { cont.resume(it) }
                    .addOnFailureListener { cont.resumeWithException(it) }
            }
            val lines = text.textBlocks.flatMap { b -> b.lines.map { it.text } }
            return parse(lines, subjects)
        } finally {
            recognizer.close()
        }
    }

    fun parse(lines: List<String>, subjects: List<Subject>): List<DraftEntry> {
        var day = 1
        val out = mutableListOf<DraftEntry>()
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val lower = line.lowercase()
            val dIdx = dayKeys.indexOfFirst { Regex("\b$it").containsMatchIn(lower) }
            if (dIdx >= 0) day = dIdx + 1

            val m = timeRx.find(line) ?: continue
            val g = m.groupValues
            val startAp = g[3].lowercase().ifEmpty { null }
            val endAp = g[6].lowercase().ifEmpty { null }
            val start = toMin(g[1].toInt(), g[2].toInt(), startAp ?: endAp) ?: continue
            val end = toMin(g[4].toInt(), g[5].toInt(), endAp ?: startAp) ?: continue
            if (end <= start) continue

            val withoutTime = line.replace(m.value, " ")
            val roomMatch = roomRx.find(withoutTime)?.value?.trim() ?: ""
            val rest = withoutTime.replace(roomMatch, " ").trim(' ', '-', ':', '|', ',')
            val subject = subjects.firstOrNull { matches(rest, it) }
            out += DraftEntry(day, subject?.id, rest, start, end, roomMatch)
        }
        return out
    }

    private fun matches(text: String, s: Subject): Boolean {
        if (s.shortName.isNotBlank() &&
            Regex("\b" + Regex.escape(s.shortName) + "\b", RegexOption.IGNORE_CASE).containsMatchIn(text)
        ) return true
        return s.name.isNotBlank() && text.contains(s.name, ignoreCase = true)
    }

    private fun toMin(h: Int, m: Int, ap: String?): Int? {
        if (h > 23 || m > 59) return null
        var hh = h
        when (ap) {
            "pm" -> if (hh < 12) hh += 12
            "am" -> if (hh == 12) hh = 0
            else -> if (hh in 1..7) hh += 12
        }
        return hh * 60 + m
    }
}

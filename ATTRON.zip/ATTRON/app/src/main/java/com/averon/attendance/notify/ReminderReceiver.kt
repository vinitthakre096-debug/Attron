package com.averon.attendance.notify

object ReminderReceiver {
    fun scheduleAll(context: android.content.Context) {}
}

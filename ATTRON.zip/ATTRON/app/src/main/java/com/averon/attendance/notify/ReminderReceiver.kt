package com.averon.attendance.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.averon.attendance.AttronApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Fires at the end of a lecture: re-arms next week's alarm, then posts the attendance notification. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("entryId", -1L)
        if (id < 0) return
        val app = context.applicationContext as AttronApp
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val entry = app.db.timetableDao().get(id)
                if (entry == null || !entry.active) return@launch

                ReminderScheduler.schedule(context, entry)

                val settings = app.settings.flow.first()
                if (!settings.notifications) return@launch

                val today = LocalDate.now().toEpochDay()
                // Already marked (or replaced) for today: don't notify again.
                if (app.db.attendanceDao().find(id, today) != null) return@launch

                val subject = app.db.subjectDao().get(entry.subjectId) ?: return@launch
                NotificationHelper.show(context, entry, subject, today)
            } finally {
                pending.finish()
            }
        }
    }
}

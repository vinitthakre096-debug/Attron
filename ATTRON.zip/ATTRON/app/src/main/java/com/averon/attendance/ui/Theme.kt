package com.averon.attendance.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.averon.attendance.data.AppTheme
import com.averon.attendance.data.Status

/** Breeze: soft cream background with sage-green accents. */
private val Breeze = lightColorScheme(
    primary = Color(0xFF6F9674),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDEBD9),
    onPrimaryContainer = Color(0xFF1F3323),
    secondary = Color(0xFF8DA58F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE6EFE2),
    onSecondaryContainer = Color(0xFF26352A),
    background = Color(0xFFF8F3E6),
    onBackground = Color(0xFF2B2F26),
    surface = Color(0xFFFFFBF0),
    onSurface = Color(0xFF2B2F26),
    surfaceVariant = Color(0xFFEAE6D6),
    onSurfaceVariant = Color(0xFF5B6155),
    outline = Color(0xFF9AA08F),
    error = Color(0xFFC0534B)
)

/** Dusk: muted dark interface with subtle green accents. */
private val Dusk = darkColorScheme(
    primary = Color(0xFF8FB996),
    onPrimary = Color(0xFF0F2415),
    primaryContainer = Color(0xFF2B4331),
    onPrimaryContainer = Color(0xFFCFE8D3),
    secondary = Color(0xFF9DB7A2),
    onSecondary = Color(0xFF14241A),
    secondaryContainer = Color(0xFF2A3A2E),
    onSecondaryContainer = Color(0xFFD3E6D6),
    background = Color(0xFF14171A),
    onBackground = Color(0xFFE4E6E3),
    surface = Color(0xFF1C2024),
    onSurface = Color(0xFFE4E6E3),
    surfaceVariant = Color(0xFF2A3036),
    onSurfaceVariant = Color(0xFFB6BCB7),
    outline = Color(0xFF6B736D),
    error = Color(0xFFE5837B)
)

fun isDarkTheme(theme: AppTheme, systemDark: Boolean): Boolean = when (theme) {
    AppTheme.SYSTEM -> systemDark
    AppTheme.BREEZE -> false
    AppTheme.DUSK -> true
}

@Composable
fun AttronTheme(theme: AppTheme, content: @Composable () -> Unit) {
    val dark = isDarkTheme(theme, isSystemInDarkTheme())
    MaterialTheme(colorScheme = if (dark) Dusk else Breeze, content = content)
}

fun statusColor(s: Status): Color = when (s) {
    Status.PRESENT -> Color(0xFF4F9D69)
    Status.ABSENT -> Color(0xFFD0645C)
    Status.OFF -> Color(0xFF8E9A92)
}

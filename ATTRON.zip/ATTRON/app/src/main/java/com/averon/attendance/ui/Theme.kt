package com.averon.attendance.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.averon.attendance.data.AppTheme
import com.averon.attendance.data.Status

private fun palette(
    accent: Color,
    background: Color,
    surface: Color,
    onSurface: Color,
    variant: Color,
    outline: Color
) = lightColorScheme(
    primary = accent, onPrimary = Color.White,
    primaryContainer = accent.copy(alpha = 0.16f), onPrimaryContainer = onSurface,
    secondary = accent.copy(alpha = 0.72f), onSecondary = Color.White,
    secondaryContainer = variant, onSecondaryContainer = onSurface,
    background = background, onBackground = onSurface,
    surface = surface, onSurface = onSurface,
    surfaceVariant = variant, onSurfaceVariant = onSurface.copy(alpha = 0.70f),
    outline = outline, error = Color(0xFFD9433A)
)

private fun midnightScheme(accent: Color) = darkColorScheme(
    primary = accent, onPrimary = Color(0xFF081B17),
    primaryContainer = accent.copy(alpha = 0.22f), onPrimaryContainer = Color(0xFFE5F4EF),
    secondary = Color(0xFF8DC9B5), onSecondary = Color(0xFF10221D),
    secondaryContainer = Color(0xFF203A34), onSecondaryContainer = Color(0xFFD9EEE7),
    background = Color(0xFF101B20), onBackground = Color(0xFFEAF2F2),
    surface = Color(0xFF17272D), onSurface = Color(0xFFEAF2F2),
    surfaceVariant = Color(0xFF263A40), onSurfaceVariant = Color(0xFFB5C8C9),
    outline = Color(0xFF40575B), error = Color(0xFFFF8A80)
)

private val AttronTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 32.sp,
        letterSpacing = (-0.3).sp
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 19.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp
    )
)

fun isDarkTheme(theme: AppTheme): Boolean = theme == AppTheme.MIDNIGHT

@Composable
fun AttronTheme(
    theme: AppTheme,
    accentColor: Long = 0xFF4B8B47L,
    content: @Composable () -> Unit
) {
    val accent = when (theme) {
        AppTheme.BREEZE -> Color(accentColor)
        AppTheme.MIDNIGHT -> Color(0xFF56B99B)
        AppTheme.LAVENDER -> Color(0xFF8B70B8)
        AppTheme.MOCHA -> Color(0xFF947052)
        AppTheme.ARCTIC -> Color(0xFF397EAD)
        AppTheme.ROSE -> Color(0xFFB66F88)
    }
    val scheme = when (theme) {
        AppTheme.BREEZE -> palette(accent, Color(0xFFF7F5EE), Color(0xFFFFFFFF), Color(0xFF1C211D), Color(0xFFECE9DF), Color(0xFFD6D2C4))
        AppTheme.MIDNIGHT -> midnightScheme(accent)
        AppTheme.LAVENDER -> palette(Color(0xFF8B70B8), Color(0xFFF7F3FC), Color(0xFFFFFCFF), Color(0xFF292333), Color(0xFFECE4F5), Color(0xFFD8CBE8))
        AppTheme.MOCHA -> palette(Color(0xFF947052), Color(0xFFF7F1E9), Color(0xFFFFFCF7), Color(0xFF33271F), Color(0xFFEDE1D3), Color(0xFFD9C7B3))
        AppTheme.ARCTIC -> palette(Color(0xFF397EAD), Color(0xFFF0F7FC), Color(0xFFFFFFFF), Color(0xFF1B2B38), Color(0xFFDDECF6), Color(0xFFC5DCEB))
        AppTheme.ROSE -> palette(Color(0xFFB66F88), Color(0xFFFCF3F6), Color(0xFFFFFCFD), Color(0xFF35232B), Color(0xFFF2E1E8), Color(0xFFE5C9D5))
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = AttronTypography,
        content = content
    )
}

fun statusColor(s: Status): Color = when (s) {
    Status.PRESENT -> Color(0xFF468C43)
    Status.ABSENT -> Color(0xFFD93B32)
    Status.OFF -> Color(0xFF9EA5A0)
}

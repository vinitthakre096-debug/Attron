package com.averon.attendance.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.averon.attendance.data.AppTheme
import com.averon.attendance.data.Status

private fun breezeScheme(accent: Color) = lightColorScheme(
    primary = accent,
    onPrimary = Color.White,
    primaryContainer = accent.copy(alpha = 0.16f),
    onPrimaryContainer = Color(0xFF1C2D1B),
    secondary = Color(0xFF6B8A67),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8EFE4),
    onSecondaryContainer = Color(0xFF223320),
    background = Color(0xFFF7F5EE),
    onBackground = Color(0xFF1C211D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1C211D),
    surfaceVariant = Color(0xFFECE9DF),
    onSurfaceVariant = Color(0xFF5D655E),
    outline = Color(0xFFD6D2C4),
    error = Color(0xFFD9433A)
)

private fun duskScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color(0xFF161324),
    primaryContainer = accent.copy(alpha = 0.24f),
    onPrimaryContainer = Color(0xFFEDE8F8),
    secondary = Color(0xFFB59EC9),
    onSecondary = Color(0xFF1E1729),
    secondaryContainer = Color(0xFF2E273E),
    onSecondaryContainer = Color(0xFFE6DCF2),
    background = Color(0xFF1C1926),
    onBackground = Color(0xFFF1EEF7),
    surface = Color(0xFF262233),
    onSurface = Color(0xFFF1EEF7),
    surfaceVariant = Color(0xFF332E44),
    onSurfaceVariant = Color(0xFFBDB6CC),
    outline = Color(0xFF47405C),
    error = Color(0xFFF07167)
)

private fun darkScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color(0xFF101712),
    primaryContainer = accent.copy(alpha = 0.22f),
    onPrimaryContainer = Color(0xFFE2ECE4),
    secondary = Color(0xFF8FA893),
    onSecondary = Color(0xFF111A13),
    secondaryContainer = Color(0xFF222926),
    onSecondaryContainer = Color(0xFFD4E0D6),
    background = Color(0xFF121517),
    onBackground = Color(0xFFECEEEB),
    surface = Color(0xFF1B1F23),
    onSurface = Color(0xFFECEEEB),
    surfaceVariant = Color(0xFF262B30),
    onSurfaceVariant = Color(0xFFA7B0AA),
    outline = Color(0xFF363D44),
    error = Color(0xFFE57373)
)

private val AttronTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 32.sp,
        letterSpacing = (-0.3).sp
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 19.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp
    )
)

fun isDarkTheme(theme: AppTheme): Boolean = theme != AppTheme.BREEZE

@Composable
fun AttronTheme(
    theme: AppTheme,
    accentColor: Long = 0xFF4B8B47L,
    content: @Composable () -> Unit
) {
    val accent = Color(accentColor)
    val scheme = when (theme) {
        AppTheme.BREEZE -> breezeScheme(accent)
        AppTheme.DUSK -> duskScheme(accent)
        AppTheme.DARK -> darkScheme(accent)
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = AttronTypography,
        content = content
    )
}

fun statusColor(s: Status): Color = when (s) {
    Status.PRESENT -> Color(0xFF468C43)
    Status.ABSENT -> Color(0xFFD93B32)
    Status.OFF -> Color(0xFF9EA5A0)
}

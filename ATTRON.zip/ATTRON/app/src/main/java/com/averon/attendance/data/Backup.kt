package com.averon.attendance.data

import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

object BackupManager {

    suspend fun export(db: AppDatabase): String {
        val subjects = JSONArray()
        db.subjectDao().allOnce().forEach {
            subjects.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("shortName", it.shortName)
                    .put("color", it.color)
            )
        }
        val entries = JSONArray()
        db.timetableDao().allOnce().forEach {
            entries.put(
                JSONObject()
                    .put("id", it.id)
                    .put("subjectId", it.subjectId)
                    .put("dayOfWeek", it.dayOfWeek)
                    .put("startMin", it.startMin)
                    .put("endMin", it.endMin)
                    .put("room", it.room)
                    .put("isExtra", it.isExtra)
                    .put("isTemporary", it.isTemporary)
                    .put("active", it.active)
            )
        }
        val records = JSONArray()
        db.attendanceDao().allOnce().forEach {
            records.put(
                JSONObject()
                    .put("id", it.id)
                    .put("subjectId", it.subjectId)
                    .put("date", it.date)
                    .put("startMin", it.startMin)
                    .put("endMin", it.endMin)
                    .put("status", it.status.name)
                    .put("type", it.type.name)
                    .put("timetableEntryId", it.timetableEntryId ?: JSONObject.NULL)
                    .put("scheduledSubjectId", it.scheduledSubjectId ?: JSONObject.NULL)
                    .put("room", it.room)
            )
        }
        return JSONObject()
            .put("app", "ATTRON")
            .put("version", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("subjects", subjects)
            .put("timetable", entries)
            .put("attendance", records)
            .toString(2)
    }

    suspend fun import(db: AppDatabase, text: String) {
        val root = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw IllegalArgumentException("This file is not a valid backup (not JSON).")
        }
        if (root.optString("app") != "ATTRON") {
            throw IllegalArgumentException("This file is not an ATTRON backup.")
        }
        if (root.optInt("version", -1) != 1) {
            throw IllegalArgumentException("Unsupported backup version.")
        }

        val subjects: List<Subject>
        val entries: List<TimetableEntry>
        val records: List<AttendanceRecord>
        try {
            val sa = root.getJSONArray("subjects")
            val ea = root.getJSONArray("timetable")
            val ra = root.getJSONArray("attendance")

            subjects = (0 until sa.length()).map {
                val o = sa.getJSONObject(it)
                Subject(o.getLong("id"), o.getString("name"), o.getString("shortName"), o.getLong("color"))
            }
            val subjectIds = subjects.map { it.id }.toSet()

            entries = (0 until ea.length()).map {
                val o = ea.getJSONObject(it)
                TimetableEntry(
                    id = o.getLong("id"),
                    subjectId = o.getLong("subjectId"),
                    dayOfWeek = o.getInt("dayOfWeek"),
                    startMin = o.getInt("startMin"),
                    endMin = o.getInt("endMin"),
                    room = o.optString("room", ""),
                    isExtra = o.optBoolean("isExtra", false),
                    isTemporary = o.optBoolean("isTemporary", false),
                    active = o.optBoolean("active", true)
                )
            }
            require(entries.all { it.subjectId in subjectIds && it.dayOfWeek in 1..7 }) { "bad timetable" }
            val entryIds = entries.map { it.id }.toSet()

            records = (0 until ra.length()).map {
                val o = ra.getJSONObject(it)
                val entryId = if (o.isNull("timetableEntryId")) null else o.getLong("timetableEntryId")
                val schedId = if (o.isNull("scheduledSubjectId")) null else o.getLong("scheduledSubjectId")
                AttendanceRecord(
                    id = o.getLong("id"),
                    subjectId = o.getLong("subjectId"),
                    date = o.getLong("date"),
                    startMin = o.getInt("startMin"),
                    endMin = o.getInt("endMin"),
                    status = Status.valueOf(o.getString("status")),
                    type = ClassType.valueOf(o.getString("type")),
                    timetableEntryId = if (entryId != null && entryId in entryIds) entryId else null,
                    scheduledSubjectId = schedId,
                    room = o.optString("room", "")
                )
            }
            require(records.all { it.subjectId in subjectIds }) { "bad attendance" }
        } catch (e: Exception) {
            throw IllegalArgumentException("The backup file is damaged or incomplete.")
        }

        db.withTransaction {
            db.attendanceDao().deleteAll()
            db.timetableDao().deleteAll()
            db.subjectDao().deleteAll()
            db.subjectDao().insertAll(subjects)
            db.timetableDao().insertAll(entries)
            db.attendanceDao().insertAll(records)
        }
    }
}

package com.averon.attendance.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.ClassType
import com.averon.attendance.data.Status
import com.averon.attendance.data.shortageText
import com.averon.attendance.data.stats
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun ReportsScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val records by vm.records.collectAsState()
    val titles = listOf("Summary", "History", "Replaced", "Extra")

    Column(Modifier.fillMaxSize()) {
        PageTitle("Reports")
        TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
            titles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, maxLines = 1) })
            }
        }
        when (tab) {
            0 -> SummaryTab(vm)
            1 -> HistoryTab(vm, records, "No attendance history yet.")
            2 -> HistoryTab(vm, records.filter { it.type == ClassType.REPLACEMENT }, "No replacement classes recorded.")
            else -> HistoryTab(vm, records.filter { it.type == ClassType.EXTRA }, "No extra classes recorded.")
        }
    }
}

@Composable
private fun SummaryTab(vm: MainViewModel) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val settings by vm.settings.collectAsState()
    val target = settings.target
    val overall = remember(records) { records.stats() }

    val trend = remember(records) {
        val counted = records.filter { it.status != Status.OFF }.groupBy { it.date }.toSortedMap()
        var p = 0
        var a = 0
        val out = mutableListOf<Float>()
        counted.values.forEach { day ->
            day.forEach { if (it.status == Status.PRESENT) p++ else a++ }
            out += p * 100f / (p + a)
        }
        out
    }
    val monthly = remember(records) {
        records.filter { it.status != Status.OFF }
            .groupBy { YearMonth.from(LocalDate.ofEpochDay(it.date)) }
            .toList()
            .sortedByDescending { it.first }
    }
    val monthFmt = remember { DateTimeFormatter.ofPattern("MMM yyyy") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AttCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        percent = overall.percent.toFloat(),
                        diameter = 96.dp,
                        label = if (overall.total == 0) "–" else "%.0f%%".format(overall.percent)
                    )
                    Spacer(Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Overall", style = MaterialTheme.typography.titleMedium)
                        Text("Present ${overall.present} · Absent ${overall.absent}", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Target $target%",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            shortageText(overall, target),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (overall.total > 0 && overall.percent < target) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
        item { SectionTitle("Subject-wise") }
        if (subjects.isEmpty()) item { EmptyState("No subjects yet.") }
        items(subjects, key = { it.id }) { s ->
            val st = remember(records, s.id) { records.filter { it.subjectId == s.id }.stats() }
            AttCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ColorDot(Color(s.color))
                    Spacer(Modifier.width(8.dp))
                    Text(s.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Text(
                        if (st.total == 0) "–" else "%.1f%%".format(st.percent),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (st.percent / 100.0).toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(s.color)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Present ${st.present} · Absent ${st.absent}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    shortageText(st, target),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (st.total > 0 && st.percent < target) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
            }
        }
        item { SectionTitle("Attendance trend") }
        item {
            AttCard {
                if (trend.size < 2) {
                    Text("Mark attendance on at least two days to see a trend.", style = MaterialTheme.typography.bodySmall)
                } else {
                    TrendChart(trend)
                    Text(
                        "Cumulative attendance % over time",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item { SectionTitle("Monthly summary") }
        if (monthly.isEmpty()) item { EmptyState("No records yet.") }
        items(monthly, key = { it.first.toString() }) { (ym, list) ->
            val st = list.stats()
            AttCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(ym.format(monthFmt), style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Text("P ${st.present} · A ${st.absent} · ${"%.0f".format(st.percent)}%")
                }
            }
        }
    }
}

@Composable
private fun TrendChart(points: List<Float>) {
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val w = size.width
        val h = size.height
        listOf(0f, 0.5f, 1f).forEach { f -> drawLine(grid, Offset(0f, h * f), Offset(w, h * f)) }
        val path = Path()
        points.forEachIndexed { i, p ->
            val x = w * i / (points.size - 1)
            val y = h * (1f - p / 100f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, line, style = Stroke(width = 4f, cap = StrokeCap.Round))
    }
}

@Composable
private fun HistoryTab(vm: MainViewModel, list: List<AttendanceRecord>, emptyText: String) {
    val subjects by vm.subjects.collectAsState()
    val subjMap = remember(subjects) { subjects.associateBy { it.id } }
    var editing by remember { mutableStateOf<AttendanceRecord?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (list.isEmpty()) item { EmptyState(emptyText) }
        items(list, key = { it.id }) { r -> RecordRow(r, subjMap) { editing = r } }
    }

    editing?.let { r ->
        EditRecordDialog(
            record = r,
            subjectName = subjMap[r.subjectId]?.name ?: "Class",
            onSave = {
                vm.updateRecord(it)
                editing = null
            },
            onDelete = {
                vm.deleteRecord(r)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
}

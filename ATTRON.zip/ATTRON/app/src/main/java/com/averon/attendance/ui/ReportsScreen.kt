package com.averon.attendance.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.ClassType
import com.averon.attendance.data.Status
import com.averon.attendance.data.Subject
import com.averon.attendance.data.shortageText
import com.averon.attendance.data.stats
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

@Composable
fun ReportsScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Overall, 1: Subject-wise, 2: Monthly
    val tabTitles = listOf("Overall", "Subject-wise", "Monthly")

    var selectedSubjectDetail by remember { mutableStateOf<Subject?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Reports", onBack = onBack)

        // Segmented Pill Bar: Overall | Subject-wise | Monthly
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 1.dp
        ) {
            Row(
                modifier = Modifier.padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                tabTitles.forEachIndexed { idx, title ->
                    val selected = selectedTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary
                                else Color.Transparent
                            )
                            .clickable {
                                selectedTab = idx
                                selectedSubjectDetail = null
                            }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        if (selectedSubjectDetail != null) {
            SubjectDetailScreen(
                vm = vm,
                subject = selectedSubjectDetail!!,
                onBack = { selectedSubjectDetail = null }
            )
        } else {
            when (selectedTab) {
                0 -> OverallReportTab(vm = vm, onViewAllSubjects = { selectedTab = 1 })
                1 -> SubjectWiseReportTab(vm = vm, onSelectSubject = { selectedSubjectDetail = it })
                else -> MonthlyReportTab(vm = vm, onSelectSubject = { selectedSubjectDetail = it })
            }
        }
    }
}

@Composable
private fun OverallReportTab(
    vm: MainViewModel,
    onViewAllSubjects: () -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val settings by vm.settings.collectAsState()
    val overall = remember(records) { records.stats() }

    // Problem 14: Real working dynamic trend chart from actual database records
    val trendPoints = remember(records) {
        val counted = records.filter { it.status != Status.OFF }.groupBy { it.date }.toSortedMap()
        var p = 0
        var a = 0
        val out = mutableListOf<Float>()
        if (counted.isEmpty()) {
            out.add(100f)
        } else {
            counted.values.forEach { day ->
                day.forEach { if (it.status == Status.PRESENT) p++ else a++ }
                val total = p + a
                out.add(if (total == 0) 100f else (p * 100f / total))
            }
        }
        out
    }

    val deltaText = remember(trendPoints) {
        if (trendPoints.size >= 2) {
            val diff = (trendPoints.last() - trendPoints.first()).roundToInt()
            if (diff >= 0) "+$diff% from start" else "$diff% from start"
        } else {
            "Real-time attendance trend"
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ReferenceAttendanceRing(
                        percent = overall.percent.toFloat(),
                        label = if (overall.total == 0) "0%" else "%.0f%%".format(overall.percent),
                        subLabel = "Attendance",
                        diameter = 108.dp
                    )
                    Spacer(Modifier.width(20.dp))
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ReportStatLine(statusColor(Status.PRESENT), "Present", overall.present.toString())
                        ReportStatLine(statusColor(Status.ABSENT), "Absent", overall.absent.toString())
                        ReportStatLine(statusColor(Status.OFF), "Total", overall.total.toString())
                    }
                }
            }
        }

        item {
            GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                Text(
                    text = "Trend",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = deltaText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(10.dp))
                AreaTrendChart(points = trendPoints)
            }
        }

        item {
            GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Subject-wise",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(
                        onClick = onViewAllSubjects,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "View All",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                if (subjects.isEmpty()) {
                    Text(
                        text = "No subjects added yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        subjects.forEach { s ->
                            val st = remember(records, s.id) {
                                records.filter { it.subjectId == s.id }.stats()
                            }
                            val pct = if (st.total == 0) 0f else st.percent.toFloat()
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = s.shortName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(56.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth((pct / 100f).coerceIn(0f, 1f))
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(50))
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    text = if (st.total == 0) "–" else "${pct.roundToInt()}%",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(42.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubjectWiseReportTab(
    vm: MainViewModel,
    onSelectSubject: (Subject) -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val settings by vm.settings.collectAsState()
    val target = settings.target

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (subjects.isEmpty()) {
            item { EmptyState("No subjects added yet. Add subjects in More → Subjects.") }
        }
        items(subjects, key = { it.id }) { s ->
            val st = remember(records, s.id) { records.filter { it.subjectId == s.id }.stats() }
            val offCount = remember(records, s.id) { records.count { it.subjectId == s.id && it.status == Status.OFF } }
            GlassCard(
                containerAlpha = 0.94f,
                cornerRadius = 20.dp,
                onClick = { onSelectSubject(s) }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SubjectIconBadge(s, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Present ${st.present} · Absent ${st.absent}" +
                                if (offCount > 0) " · Off $offCount" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (st.total == 0) "–" else "%.1f%%".format(st.percent),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (st.total > 0 && st.percent < target) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { (st.percent / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50)),
                    color = Color(s.color)
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = shortageText(st, target),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (st.total > 0 && st.percent < target) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun MonthlyReportTab(
    vm: MainViewModel,
    onSelectSubject: (Subject) -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()

    val monthly = remember(records) {
        records.filter { it.status != Status.OFF }
            .groupBy { YearMonth.from(LocalDate.ofEpochDay(it.date)) }
            .toList()
            .sortedByDescending { it.first }
    }
    val monthFmt = remember { DateTimeFormatter.ofPattern("MMMM yyyy") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (monthly.isEmpty()) {
            item { EmptyState("No attendance records in any month yet.") }
        } else {
            items(monthly, key = { it.first.toString() }) { (ym, list) ->
                val st = list.stats()
                GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ReferenceAttendanceRing(
                            percent = st.percent.toFloat(),
                            label = "${st.percent.roundToInt()}%",
                            subLabel = ym.format(DateTimeFormatter.ofPattern("MMM")),
                            diameter = 90.dp
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = ym.format(monthFmt),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Present ${st.present} · Absent ${st.absent} · Total ${st.total}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "Subjects in ${ym.format(DateTimeFormatter.ofPattern("MMM yyyy"))}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(10.dp))

                    // Problem 10: Redesigned into spacious individual cards for each subject to fix touch target & blank space
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        subjects.forEach { s ->
                            val sList = list.filter { it.subjectId == s.id }
                            val sSt = sList.stats()
                            val pct = if (sSt.total == 0) 0f else sSt.percent.toFloat()
                            GlassCard(
                                containerAlpha = 0.85f,
                                cornerRadius = 16.dp,
                                onClick = { onSelectSubject(s) }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    SubjectIconBadge(s, size = 36.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            text = s.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = "Present ${sSt.present} · Absent ${sSt.absent}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = if (sSt.total == 0) "–" else "${pct.roundToInt()}%",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { (pct / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(7.dp)
                                        .clip(RoundedCornerShape(50)),
                                    color = Color(s.color)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUBJECT DETAIL SCREEN (Full Name + Ring + 4 Tabs: All, Regular, Extra, Replace)
// ==========================================
@Composable
private fun SubjectDetailScreen(
    vm: MainViewModel,
    subject: Subject,
    onBack: () -> Unit
) {
    val records by vm.records.collectAsState()
    val subjMap = remember(subject) { mapOf(subject.id to subject) }

    var tabIndex by remember { mutableIntStateOf(0) } // 0: All, 1: Regular, 2: Extra, 3: Replace
    val tabs = listOf("All", "Regular", "Extra", "Replace")

    var editingRecord by remember { mutableStateOf<AttendanceRecord?>(null) }

    // Problem 5: Descending order dates (newest 15 on top, then 14, 13...)
    val subjectRecords = remember(records, subject.id) {
        records.filter { it.subjectId == subject.id }.sortedByDescending { it.date }
    }

    val st = remember(subjectRecords) { subjectRecords.stats() }
    val attended = st.present
    val notAttended = st.absent
    val offCount = remember(subjectRecords) { subjectRecords.count { it.status == Status.OFF } }

    val filteredList = remember(subjectRecords, tabIndex) {
        when (tabIndex) {
            1 -> subjectRecords.filter { it.type == ClassType.REGULAR }
            2 -> subjectRecords.filter { it.type == ClassType.EXTRA }
            3 -> subjectRecords.filter { it.type == ClassType.REPLACEMENT }
            else -> subjectRecords
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text("← Back to Reports", color = MaterialTheme.colorScheme.primary)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card: Full Name + Circular Ring + Attended / Not Attended / Off
            item {
                GlassCard(containerAlpha = 0.94f, cornerRadius = 24.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ReferenceAttendanceRing(
                            percent = st.percent.toFloat(),
                            label = if (st.total == 0) "0%" else "%.0f%%".format(st.percent),
                            subLabel = subject.shortName,
                            diameter = 104.dp
                        )
                        Spacer(Modifier.width(18.dp))
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = subject.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(2.dp))
                            ReportStatLine(statusColor(Status.PRESENT), "Classes Attended", attended.toString())
                            ReportStatLine(statusColor(Status.ABSENT), "Not Attended", notAttended.toString())
                            ReportStatLine(statusColor(Status.OFF), "Off Classes", offCount.toString())
                        }
                    }
                }
            }

            // 4 Filter Tabs: All | Regular | Extra | Replace
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        tabs.forEachIndexed { idx, title ->
                            val selected = tabIndex == idx
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (selected) MaterialTheme.colorScheme.primary
                                        else Color.Transparent
                                    )
                                    .clickable { tabIndex = idx }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Date-wise Descending Class Rows (tap to edit status)
            if (filteredList.isEmpty()) {
                item {
                    EmptyState("No ${tabs[tabIndex].lowercase()} classes recorded for ${subject.shortName}.")
                }
            } else {
                items(filteredList, key = { it.id }) { r ->
                    RecordRow(r, subjMap) { editingRecord = r }
                }
            }
        }
    }

    editingRecord?.let { r ->
        EditRecordDialog(
            record = r,
            subjectName = subject.name,
            onSave = { updated ->
                vm.updateRecord(updated)
                editingRecord = null
            },
            onDelete = {
                vm.deleteRecord(r)
                editingRecord = null
            },
            onDismiss = { editingRecord = null }
        )
    }
}

@Composable
private fun ReportStatLine(dot: Color, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ColorDot(dot, diameter = 8.dp)
        Spacer(Modifier.width(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun AreaTrendChart(points: List<Float>) {
    val lineColor = MaterialTheme.colorScheme.primary
    val fillTop = lineColor.copy(alpha = 0.28f)
    val fillBottom = lineColor.copy(alpha = 0.02f)

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(95.dp)
    ) {
        val w = size.width
        val h = size.height
        val minVal = (points.minOrNull() ?: 50f) - 8f
        val maxVal = ((points.maxOrNull() ?: 100f) + 5f).coerceAtMost(100f)
        val range = (maxVal - minVal).coerceAtLeast(10f)

        val coords = points.mapIndexed { i, v ->
            val x = if (points.size == 1) w / 2f else w * i / (points.size - 1)
            val norm = ((v - minVal) / range).coerceIn(0f, 1f)
            val y = h * (1f - norm)
            Offset(x, y)
        }

        val linePath = Path().apply {
            coords.forEachIndexed { i, pt ->
                if (i == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
            }
        }

        val areaPath = Path().apply {
            addPath(linePath)
            lineTo(coords.last().x, h)
            lineTo(coords.first().x, h)
            close()
        }

        drawPath(
            path = areaPath,
            brush = Brush.verticalGradient(listOf(fillTop, fillBottom))
        )
        drawPath(
            path = linePath,
            color = lineColor,
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

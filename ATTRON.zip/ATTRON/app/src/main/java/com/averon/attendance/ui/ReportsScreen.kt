package com.averon.attendance.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.ClassType
import com.averon.attendance.data.Status
import com.averon.attendance.data.shortageText
import com.averon.attendance.data.stats
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

@Composable
fun ReportsScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Overall, 1: Subject-wise, 2: Monthly & History
    val tabTitles = listOf("Overall", "Subject-wise", "Monthly")

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Reports", onBack = onBack)

        // Segmented Pill Bar: Overall | Subject-wise | Monthly
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 1.dp
        ) {
            Row(
                modifier = Modifier.padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                tabTitles.forEachIndexed { idx, title ->
                    val selected = selectedTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary
                                else Color.Transparent
                            )
                            .clickable { selectedTab = idx }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        when (selectedTab) {
            0 -> OverallReportTab(vm = vm, onViewAllSubjects = { selectedTab = 1 })
            1 -> SubjectWiseReportTab(vm = vm)
            else -> MonthlyAndHistoryTab(vm = vm)
        }
    }
}

@Composable
private fun OverallReportTab(
    vm: MainViewModel,
    onViewAllSubjects: () -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val settings by vm.settings.collectAsState()
    val overall = remember(records) { records.stats() }

    val trendPoints = remember(records) {
        val counted = records.filter { it.status != Status.OFF }.groupBy { it.date }.toSortedMap()
        var p = 0
        var a = 0
        val out = mutableListOf<Float>()
        counted.values.forEach { day ->
            day.forEach { if (it.status == Status.PRESENT) p++ else a++ }
            out += p * 100f / (p + a)
        }
        out
    }

    val deltaText = remember(trendPoints) {
        if (trendPoints.size >= 2) {
            val diff = (trendPoints.last() - trendPoints.first()).roundToInt()
            if (diff >= 0) "+$diff% from start" else "$diff% from start"
        } else {
            "Track daily to view trend"
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Circular Overall Attendance Card
        item {
            GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ReferenceAttendanceRing(
                        percent = overall.percent.toFloat(),
                        label = if (overall.total == 0) "0%" else "%.0f%%".format(overall.percent),
                        subLabel = "Attendance",
                        diameter = 108.dp
                    )
                    Spacer(Modifier.width(20.dp))
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ReportStatLine(statusColor(Status.PRESENT), "Present", overall.present.toString())
                        ReportStatLine(statusColor(Status.ABSENT), "Absent", overall.absent.toString())
                        ReportStatLine(statusColor(Status.OFF), "Total", overall.total.toString())
                    }
                }
            }
        }

        // 2. Trend Card with Shaded Area Line Graph
        item {
            GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                Text(
                    text = "Trend",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = deltaText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(10.dp))
                AreaTrendChart(
                    points = if (trendPoints.size >= 2) trendPoints else listOf(68f, 71f, 70f, 74f, 75f, 78f)
                )
            }
        }

        // 3. Subject-wise Card ("Subject-wise   View All")
        item {
            GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Subject-wise",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(
                        onClick = onViewAllSubjects,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "View All",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                if (subjects.isEmpty()) {
                    Text(
                        text = "No subjects added yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        subjects.forEach { s ->
                            val st = remember(records, s.id) {
                                records.filter { it.subjectId == s.id }.stats()
                            }
                            val pct = if (st.total == 0) 0f else st.percent.toFloat()
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = s.shortName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(56.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth((pct / 100f).coerceIn(0f, 1f))
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(50))
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    text = if (st.total == 0) "–" else "${pct.roundToInt()}%",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(42.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportStatLine(dot: Color, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ColorDot(dot, diameter = 8.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun AreaTrendChart(points: List<Float>) {
    val lineColor = MaterialTheme.colorScheme.primary
    val fillTop = lineColor.copy(alpha = 0.28f)
    val fillBottom = lineColor.copy(alpha = 0.02f)

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(95.dp)
    ) {
        val w = size.width
        val h = size.height
        val minVal = (points.minOrNull() ?: 50f) - 8f
        val maxVal = ((points.maxOrNull() ?: 100f) + 5f).coerceAtMost(100f)
        val range = (maxVal - minVal).coerceAtLeast(10f)

        val coords = points.mapIndexed { i, v ->
            val x = if (points.size == 1) w / 2f else w * i / (points.size - 1)
            val norm = ((v - minVal) / range).coerceIn(0f, 1f)
            val y = h * (1f - norm)
            Offset(x, y)
        }

        val linePath = Path().apply {
            coords.forEachIndexed { i, pt ->
                if (i == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
            }
        }

        val areaPath = Path().apply {
            addPath(linePath)
            lineTo(coords.last().x, h)
            lineTo(coords.first().x, h)
            close()
        }

        drawPath(
            path = areaPath,
            brush = Brush.verticalGradient(listOf(fillTop, fillBottom))
        )
        drawPath(
            path = linePath,
            color = lineColor,
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun SubjectWiseReportTab(vm: MainViewModel) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val settings by vm.settings.collectAsState()
    val target = settings.target

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (subjects.isEmpty()) {
            item { EmptyState("No subjects added yet. Add subjects in More → Subjects.") }
        }
        items(subjects, key = { it.id }) { s ->
            val st = remember(records, s.id) { records.filter { it.subjectId == s.id }.stats() }
            val offCount = remember(records, s.id) { records.count { it.subjectId == s.id && it.status == Status.OFF } }
            GlassCard(containerAlpha = 0.94f, cornerRadius = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SubjectIconBadge(s, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "Present ${st.present} · Absent ${st.absent}" +
                                if (offCount > 0) " · Off $offCount" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (st.total == 0) "–" else "%.1f%%".format(st.percent),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (st.total > 0 && st.percent < target) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { (st.percent / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50)),
                    color = Color(s.color)
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = shortageText(st, target),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (st.total > 0 && st.percent < target) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun MonthlyAndHistoryTab(vm: MainViewModel) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val subjMap = remember(subjects) { subjects.associateBy { it.id } }

    var historyFilter by remember { mutableIntStateOf(0) } // 0: All, 1: Replaced, 2: Extra
    var editingRecord by remember { mutableStateOf<AttendanceRecord?>(null) }

    val monthly = remember(records) {
        records.filter { it.status != Status.OFF }
            .groupBy { YearMonth.from(LocalDate.ofEpochDay(it.date)) }
            .toList()
            .sortedByDescending { it.first }
    }
    val monthFmt = remember { DateTimeFormatter.ofPattern("MMMM yyyy") }

    val filteredRecords = remember(records, historyFilter) {
        when (historyFilter) {
            1 -> records.filter { it.type == ClassType.REPLACEMENT }
            2 -> records.filter { it.type == ClassType.EXTRA }
            else -> records
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionTitle("Monthly Summary")
        }
        if (monthly.isEmpty()) {
            item { EmptyState("No monthly summary available yet.") }
        } else {
            items(monthly, key = { it.first.toString() }) { (ym, list) ->
                val st = list.stats()
                GlassCard(containerAlpha = 0.94f, cornerRadius = 18.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(ym.format(monthFmt), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                "Present ${st.present} · Absent ${st.absent} · Total ${st.total}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${st.percent.roundToInt()}%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        item {
            SectionTitle("Attendance History (Tap to edit)")
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = historyFilter == 0,
                    onClick = { historyFilter = 0 },
                    label = { Text("All History") }
                )
                FilterChip(
                    selected = historyFilter == 1,
                    onClick = { historyFilter = 1 },
                    label = { Text("Replaced") }
                )
                FilterChip(
                    selected = historyFilter == 2,
                    onClick = { historyFilter = 2 },
                    label = { Text("Extra") }
                )
            }
        }

        if (filteredRecords.isEmpty()) {
            item { EmptyState("No records in this category.") }
        } else {
            items(filteredRecords, key = { it.id }) { r ->
                RecordRow(r, subjMap) { editingRecord = r }
            }
        }
    }

    editingRecord?.let { r ->
        EditRecordDialog(
            record = r,
            subjectName = subjMap[r.subjectId]?.name ?: "Class",
            onSave = {
                vm.updateRecord(it)
                editingRecord = null
            },
            onDelete = {
                vm.deleteRecord(r)
                editingRecord = null
            },
            onDismiss = { editingRecord = null }
        )
    }
}

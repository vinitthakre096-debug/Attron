package com.averon.attendance.notify

object BootReceiver {
    fun scheduleAll(context: android.content.Context) {}
}

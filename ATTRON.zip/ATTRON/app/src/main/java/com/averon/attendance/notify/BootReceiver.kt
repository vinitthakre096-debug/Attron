package com.averon.attendance.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.averon.attendance.AttronApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Re-creates all lecture alarms after reboot, app update, or time / timezone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as AttronApp
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ReminderScheduler.scheduleAll(context, app.db.timetableDao().allOnce())
            } finally {
                pending.finish()
            }
        }
    }
}

package com.averon.attendance.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.ClassType
import com.averon.attendance.data.DAY_NAMES
import com.averon.attendance.data.Status
import com.averon.attendance.data.Subject
import com.averon.attendance.data.TimetableEntry
import com.averon.attendance.data.fmtDate
import com.averon.attendance.data.fmtTime
import com.averon.attendance.data.shortageText
import com.averon.attendance.data.stats
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val subjects by vm.subjects.collectAsState()
    val entries by vm.entries.collectAsState()
    val records by vm.records.collectAsState()
    val settings by vm.settings.collectAsState()

    val subjMap = remember(subjects) { subjects.associateBy { it.id } }
    val today = LocalDate.now().toEpochDay()
    var date by remember { mutableLongStateOf(today) }
    var replaceFor by remember { mutableStateOf<TimetableEntry?>(null) }
    var showExtra by remember { mutableStateOf(false) }

    val stats = remember(records) { records.stats() }
    val dow = LocalDate.ofEpochDay(date).dayOfWeek.value
    val dayEntries = remember(entries, date) {
        entries.filter { it.active && it.dayOfWeek == dow }.sortedBy { it.startMin }
    }
    val dayRecords = remember(records, date) { records.filter { it.date == date } }
    val extras = dayRecords.filter { it.type == ClassType.EXTRA && it.timetableEntryId == null }

    val nowMin = LocalTime.now().let { it.hour * 60 + it.minute }
    val next = if (date == today) {
        dayEntries.firstOrNull { e -> e.endMin > nowMin && dayRecords.none { r -> r.timetableEntryId == e.id } }
    } else null

    val dateLabel = when (date) {
        today -> "Today"
        today + 1 -> "Tomorrow"
        today - 1 -> "Yesterday"
        else -> fmtDate(date)
    } + " · " + DAY_NAMES[dow - 1]

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("ATTRON", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        }
        item {
            AttCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        percent = stats.percent.toFloat(),
                        diameter = 120.dp,
                        label = if (stats.total == 0) "–" else "%.1f%%".format(stats.percent)
                    )
                    Spacer(Modifier.width(20.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Overall attendance", style = MaterialTheme.typography.titleMedium)
                        Text("Present: ${stats.present}", color = statusColor(Status.PRESENT))
                        Text("Absent: ${stats.absent}", color = statusColor(Status.ABSENT))
                        Text(
                            "Total recorded: ${stats.total}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (stats.total > 0 && stats.percent < settings.target) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Below your ${settings.target}% target. " + shortageText(stats, settings.target),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
        if (next != null) {
            item {
                val s = subjMap[next.subjectId]
                AttCard {
                    Text("Next class", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(s?.name ?: "Unknown", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${fmtTime(next.startMin)} – ${fmtTime(next.endMin)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { date -= 1 }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Previous day") }
                TextButton(onClick = { pickDate(ctx, date) { date = it } }) {
                    Text(dateLabel, style = MaterialTheme.typography.titleMedium)
                }
                IconButton(onClick = { date += 1 }) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Next day") }
            }
        }
        if (subjects.isEmpty()) {
            item { EmptyState("Add your subjects in More → Subjects, then build your timetable.") }
        } else if (dayEntries.isEmpty() && extras.isEmpty()) {
            item { EmptyState("No classes scheduled for this day.") }
        }
        items(dayEntries, key = { it.id }) { e ->
            ClassCard(
                entry = e,
                subject = subjMap[e.subjectId],
                record = dayRecords.firstOrNull { it.timetableEntryId == e.id },
                subjMap = subjMap,
                onMark = { vm.mark(e, date, it) },
                onReplace = { replaceFor = e }
            )
        }
        items(extras, key = { "extra-${it.id}" }) { r -> RecordRow(r, subjMap) }
        item {
            OutlinedButton(onClick = { showExtra = true }, modifier = Modifier.fillMaxWidth(), enabled = subjects.isNotEmpty()) {
                Text("Add extra class")
            }
        }
        item { SectionTitle("Recent activity") }
        if (records.isEmpty()) {
            item { EmptyState("No attendance recorded yet.") }
        } else {
            items(records.take(5), key = { "recent-${it.id}" }) { r -> RecordRow(r, subjMap) }
        }
    }

    replaceFor?.let { e ->
        ReplacementDialog(
            entry = e,
            subjects = subjects,
            onConfirm = { sid, st ->
                vm.replace(e, date, sid, st)
                replaceFor = null
            },
            onDismiss = { replaceFor = null }
        )
    }
    if (showExtra) {
        ExtraClassDialog(
            subjects = subjects,
            defaultDate = date,
            onSave = { sid, d, s, e, room, st ->
                vm.addExtra(sid, d, s, e, room, st)
                showExtra = false
            },
            onDismiss = { showExtra = false }
        )
    }
}

@Composable
private fun ClassCard(
    entry: TimetableEntry,
    subject: Subject?,
    record: AttendanceRecord?,
    subjMap: Map<Long, Subject>,
    onMark: (Status) -> Unit,
    onReplace: () -> Unit
) {
    val isReplacement = record?.type == ClassType.REPLACEMENT
    AttCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ColorDot(Color(subject?.color ?: 0xFF888888L))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(subject?.name ?: "Unknown subject", style = MaterialTheme.typography.titleMedium)
                Text(
                    "${fmtTime(entry.startMin)} – ${fmtTime(entry.endMin)}" +
                        if (entry.room.isNotBlank()) " · Room ${entry.room}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (entry.isExtra) {
                    Text("Extra class", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            if (record != null) StatusChip(record.status)
        }
        if (isReplacement && record != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                "Replaced by ${subjMap[record.subjectId]?.name ?: "another subject"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Status.entries.forEach { st ->
                val selected = record != null && !isReplacement && record.status == st
                if (selected) {
                    Button(
                        onClick = { onMark(st) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = statusColor(st))
                    ) { Text(st.label, maxLines = 1) }
                } else {
                    OutlinedButton(
                        onClick = { onMark(st) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text(st.label, maxLines = 1) }
                }
            }
        }
        TextButton(onClick = onReplace) {
            Text(if (isReplacement) "Edit replacement" else "Different subject taught?")
        }
    }
}

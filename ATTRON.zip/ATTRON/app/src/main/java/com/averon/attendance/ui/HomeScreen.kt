package com.averon.attendance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.ClassType
import com.averon.attendance.data.Status
import com.averon.attendance.data.Subject
import com.averon.attendance.data.TimetableEntry
import com.averon.attendance.data.fmtTime
import com.averon.attendance.data.shortageText
import com.averon.attendance.data.stats
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onNavigateTab: (String) -> Unit
) {
    val subjects by vm.subjects.collectAsState()
    val entries by vm.entries.collectAsState()
    val records by vm.records.collectAsState()
    val settings by vm.settings.collectAsState()

    val subjMap = remember(subjects) { subjects.associateBy { it.id } }
    val today = LocalDate.now().toEpochDay()
    var date by remember { mutableLongStateOf(today) }
    var replaceFor by remember { mutableStateOf<TimetableEntry?>(null) }
    var showExtra by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }

    val stats = remember(records) { records.stats() }
    val dow = LocalDate.ofEpochDay(date).dayOfWeek.value
    val dayEntries = remember(entries, date) {
        entries.filter { it.active && it.dayOfWeek == dow }.sortedBy { it.startMin }
    }
    val dayRecords = remember(records, date) { records.filter { it.date == date } }

    val nowTime = LocalTime.now()
    val nowMin = nowTime.hour * 60 + nowTime.minute
    val greeting = when (nowTime.hour) {
        in 5..11 -> "Good Morning,"
        in 12..16 -> "Good Afternoon,"
        else -> "Good Evening,"
    }

    val nextClass = remember(dayEntries, dayRecords, nowMin, date) {
        if (date == today) {
            dayEntries.firstOrNull { e -> e.endMin > nowMin && dayRecords.none { r -> r.timetableEntryId == e.id } }
                ?: dayEntries.firstOrNull { e -> e.endMin > nowMin }
                ?: dayEntries.firstOrNull()
        } else {
            dayEntries.firstOrNull()
        }
    }

    val nextCountdownLabel = remember(nextClass, nowMin, date) {
        if (nextClass == null || date != today) "Scheduled"
        else {
            val diff = nextClass.startMin - nowMin
            when {
                diff > 60 -> "in ${diff / 60}h ${diff % 60}m"
                diff > 0 -> "in $diff min"
                nowMin in nextClass.startMin..nextClass.endMin -> "Ongoing"
                else -> "Completed"
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. HERO SCENIC HEADER + GLASS ATTENDANCE CARD
        item {
            Box(modifier = Modifier.fillMaxWidth()) {
                ValleyScenicBackdrop(
                    theme = settings.theme,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(355.dp),
                    showSun = true
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    // Top bar: 'A' leaf logo on left, Bell + Profile avatar on right
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        AttronLeafLogo(size = 34.dp)

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                IconButton(onClick = { onNavigateTab("settings") }) {
                                    Icon(
                                        imageVector = Icons.Outlined.Notifications,
                                        contentDescription = "Reminders",
                                        tint = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                if (settings.notifications) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(top = 11.dp, end = 11.dp)
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE58C3A))
                                    )
                                }
                            }
                            Spacer(Modifier.width(4.dp))
                            // Circular scenic avatar button -> edit profile name/course
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                                    .clickable { showProfileDialog = true }
                            ) {
                                ValleyScenicBackdrop(
                                    theme = settings.theme,
                                    modifier = Modifier.fillMaxSize(),
                                    showSun = true
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Personalized Greeting & Course Subtitle
                    Text(
                        text = "$greeting\n${settings.userName} ✨",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.clickable { showProfileDialog = true }
                    )
                    if (settings.userSubtitle.isNotBlank()) {
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = settings.userSubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    // Glassmorphism Overall Attendance Card
                    GlassCard(containerAlpha = 0.86f, cornerRadius = 24.dp) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ReferenceAttendanceRing(
                                percent = stats.percent.toFloat(),
                                label = if (stats.total == 0) "0%" else "%.0f%%".format(stats.percent),
                                subLabel = "Attendance",
                                diameter = 112.dp
                            )
                            Spacer(Modifier.width(20.dp))
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AttendanceStatRow(
                                    dotColor = statusColor(Status.PRESENT),
                                    label = "Present",
                                    count = stats.present.toString()
                                )
                                AttendanceStatRow(
                                    dotColor = statusColor(Status.ABSENT),
                                    label = "Absent",
                                    count = stats.absent.toString()
                                )
                                AttendanceStatRow(
                                    dotColor = statusColor(Status.OFF),
                                    label = "Total",
                                    count = stats.total.toString()
                                )
                            }
                        }
                        if (stats.total > 0 && stats.percent < settings.target) {
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = shortageText(stats, settings.target),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // 2. NEXT CLASS CARD (Exact Reference Layout)
        item {
            Box(Modifier.padding(horizontal = 18.dp)) {
                GlassCard(containerAlpha = 0.94f, cornerRadius = 22.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Next Class",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = nextCountdownLabel,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    if (nextClass != null) {
                        val s = subjMap[nextClass.subjectId]
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = s?.shortName ?: s?.name ?: "Class",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "${fmtTime(nextClass.startMin)} – ${fmtTime(nextClass.endMin)}" +
                                        if (nextClass.room.isNotBlank()) " · ${nextClass.room}" else "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .clickable { onNavigateTab("timetable") },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = "Open Timetable",
                                    tint = Color.White
                                )
                            }
                        }
                    } else {
                        Text(
                            text = if (subjects.isEmpty()) "Add subjects & timetable to begin" else "All classes done for today",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 3. 4 QUICK NAVIGATION SHORTCUTS (Timetable | Calendar | Reports | More)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickShortcutTile(
                    icon = Icons.Outlined.DateRange,
                    label = "Timetable",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab("timetable") }
                )
                QuickShortcutTile(
                    icon = Icons.Outlined.CalendarMonth,
                    label = "Calendar",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab("calendar") }
                )
                QuickShortcutTile(
                    icon = Icons.Outlined.Assessment,
                    label = "Reports",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab("reports") }
                )
                QuickShortcutTile(
                    icon = Icons.Outlined.MoreHoriz,
                    label = "More",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab("more") }
                )
            }
        }

        // 4. TODAY'S CLASSES QUICK ATTENDANCE MARKING (Preserves core daily marking workflow)
        if (dayEntries.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Today's Lectures",
                        style = MaterialTheme.typography.titleMedium
                    )
                    TextButton(onClick = { showExtra = true }) {
                        Text("+ Extra Class", color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            items(dayEntries, key = { it.id }) { e ->
                Box(Modifier.padding(horizontal = 18.dp)) {
                    QuickMarkClassCard(
                        entry = e,
                        subject = subjMap[e.subjectId],
                        record = dayRecords.firstOrNull { it.timetableEntryId == e.id },
                        subjMap = subjMap,
                        onMark = { vm.mark(e, date, it) },
                        onReplace = { replaceFor = e }
                    )
                }
            }
        } else if (subjects.isNotEmpty()) {
            item {
                Box(Modifier.padding(horizontal = 18.dp)) {
                    OutlinedButton(
                        onClick = { showExtra = true },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("+ Record Extra Class Today")
                    }
                }
            }
        }
    }

    replaceFor?.let { e ->
        ReplacementDialog(
            entry = e,
            subjects = subjects,
            onConfirm = { sid, st ->
                vm.replace(e, date, sid, st)
                replaceFor = null
            },
            onDismiss = { replaceFor = null }
        )
    }

    if (showExtra) {
        ExtraClassDialog(
            subjects = subjects,
            defaultDate = date,
            onSave = { sid, d, s, e, room, st ->
                vm.addExtra(sid, d, s, e, room, st)
                showExtra = false
            },
            onDismiss = { showExtra = false }
        )
    }

    if (showProfileDialog) {
        ProfileEditDialog(
            currentName = settings.userName,
            currentSubtitle = settings.userSubtitle,
            onSave = { n, sub ->
                vm.setProfile(n, sub)
                showProfileDialog = false
            },
            onDismiss = { showProfileDialog = false }
        )
    }
}

@Composable
private fun AttendanceStatRow(dotColor: Color, label: String, count: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ColorDot(dotColor, diameter = 9.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = count,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun QuickShortcutTile(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier,
        containerAlpha = 0.92f,
        cornerRadius = 18.dp,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun QuickMarkClassCard(
    entry: TimetableEntry,
    subject: Subject?,
    record: AttendanceRecord?,
    subjMap: Map<Long, Subject>,
    onMark: (Status) -> Unit,
    onReplace: () -> Unit
) {
    val isReplacement = record?.type == ClassType.REPLACEMENT
    GlassCard(cornerRadius = 20.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SubjectIconBadge(subject, size = 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = subject?.shortName ?: subject?.name ?: "Subject",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "${fmtTime(entry.startMin)} – ${fmtTime(entry.endMin)}" +
                        if (entry.room.isNotBlank()) " · ${entry.room}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (record != null) StatusChip(record.status)
        }
        if (isReplacement && record != null) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Replaced by ${subjMap[record.subjectId]?.shortName ?: "another subject"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Status.entries.forEach { st ->
                val selected = record != null && !isReplacement && record.status == st
                if (selected) {
                    Button(
                        onClick = { onMark(st) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = statusColor(st))
                    ) { Text(st.label, maxLines = 1) }
                } else {
                    OutlinedButton(
                        onClick = { onMark(st) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) { Text(st.label, maxLines = 1) }
                }
            }
        }
        TextButton(onClick = onReplace, contentPadding = PaddingValues(0.dp)) {
            Text(
                text = if (isReplacement) "Edit replacement" else "Different subject taught?",
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

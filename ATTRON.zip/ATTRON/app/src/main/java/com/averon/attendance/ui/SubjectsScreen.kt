package com.averon.attendance.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.ClassType
import com.averon.attendance.data.Subject
import com.averon.attendance.data.stats

@Composable
fun SubjectsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val subjects by vm.subjects.collectAsState()
    val records by vm.records.collectAsState()
    val subjMap = remember(subjects) { subjects.associateBy { it.id } }

    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Subject?>(null) }
    var deleting by remember { mutableStateOf<Subject?>(null) }
    var expanded by remember { mutableStateOf<Long?>(null) }
    var filter by remember { mutableIntStateOf(0) } // 0 all, 1 replacement, 2 extra

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Subjects", onBack)
        Button(
            onClick = { adding = true },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Add subject") }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (subjects.isEmpty()) item { EmptyState("No subjects yet. Add your first subject to get started.") }
            items(subjects, key = { it.id }) { s ->
                val mine = records.filter { it.subjectId == s.id }
                val st = mine.stats()
                val open = expanded == s.id
                AttCard(onClick = {
                    expanded = if (open) null else s.id
                    filter = 0
                }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ColorDot(Color(s.color), 16.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                s.shortName,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            if (st.total == 0) "–" else "%.1f%%".format(st.percent),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Total ${st.total} · Present ${st.present} · Absent ${st.absent}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = { editing = s }) { Icon(Icons.Default.Edit, "Edit") }
                        IconButton(onClick = { deleting = s }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                    if (open) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = filter == 0, onClick = { filter = 0 }, label = { Text("All") })
                            FilterChip(selected = filter == 1, onClick = { filter = 1 }, label = { Text("Replacement") })
                            FilterChip(selected = filter == 2, onClick = { filter = 2 }, label = { Text("Extra") })
                        }
                        val shown = when (filter) {
                            1 -> mine.filter { it.type == ClassType.REPLACEMENT }
                            2 -> mine.filter { it.type == ClassType.EXTRA }
                            else -> mine
                        }
                        Spacer(Modifier.height(8.dp))
                        if (shown.isEmpty()) {
                            Text(
                                "No records here yet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            shown.take(30).forEach { r -> RecordRow(r, subjMap) }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        SubjectDialog(
            initial = null,
            onSave = {
                vm.saveSubject(it)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }
    editing?.let { s ->
        SubjectDialog(
            initial = s,
            onSave = {
                vm.saveSubject(it)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete ${s.shortName}?") },
            text = { Text("This also deletes its timetable entries and all attendance records for this subject. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteSubject(s)
                    deleting = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

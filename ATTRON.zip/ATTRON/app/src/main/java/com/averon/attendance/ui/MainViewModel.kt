package com.averon.attendance.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.averon.attendance.AttronApp
import com.averon.attendance.data.AppSettings
import com.averon.attendance.data.AppTheme
import com.averon.attendance.data.AttendanceRecord
import com.averon.attendance.data.BackupManager
import com.averon.attendance.data.Status
import com.averon.attendance.data.Subject
import com.averon.attendance.data.TimetableEntry
import com.averon.attendance.notify.ReminderScheduler
import com.averon.attendance.ocr.DraftEntry
import com.averon.attendance.ocr.TimetableOcr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as AttronApp
    private val db = a.db
    private val ctx: Context get() = a.applicationContext

    val subjects = db.subjectDao().all()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<Subject>())
    val entries = db.timetableDao().all()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<TimetableEntry>())
    val records = db.attendanceDao().all()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<AttendanceRecord>())
    val settings = a.settings.flow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val drafts = MutableStateFlow<List<DraftEntry>?>(null)
    val scanning = MutableStateFlow(false)
    val message = MutableSharedFlow<String>(extraBufferCapacity = 8)

    private fun io(block: suspend () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message.tryEmit(e.message ?: "Something went wrong")
            }
        }
    }

    // ---- Subjects ----
    fun saveSubject(s: Subject) = io {
        if (s.id == 0L) db.subjectDao().insert(s) else db.subjectDao().update(s)
    }

    fun deleteSubject(s: Subject) = io {
        db.timetableDao().bySubject(s.id).forEach { ReminderScheduler.cancel(ctx, it.id) }
        db.subjectDao().delete(s)
    }

    // ---- Timetable ----
    fun saveEntry(e: TimetableEntry) = io {
        val id = if (e.id == 0L) db.timetableDao().insert(e) else {
            db.timetableDao().update(e)
            e.id
        }
        ReminderScheduler.schedule(ctx, e.copy(id = id))
    }

    fun deleteEntry(e: TimetableEntry) = io {
        ReminderScheduler.cancel(ctx, e.id)
        db.timetableDao().delete(e)
    }

    fun setEntryActive(e: TimetableEntry, active: Boolean) = io {
        val n = e.copy(active = active)
        db.timetableDao().update(n)
        ReminderScheduler.schedule(ctx, n)
    }

    // ---- Attendance ----
    fun mark(e: TimetableEntry, epochDay: Long, status: Status) = io { a.repo.mark(e, epochDay, status) }

    fun replace(e: TimetableEntry, epochDay: Long, subjectId: Long, status: Status) = io {
        a.repo.replace(e, epochDay, subjectId, status)
    }

    fun addExtra(subjectId: Long, epochDay: Long, start: Int, end: Int, room: String, status: Status) = io {
        a.repo.extra(subjectId, epochDay, start, end, room, status)
    }

    fun updateRecord(r: AttendanceRecord) = io { db.attendanceDao().upsert(r) }

    fun deleteRecord(r: AttendanceRecord) = io { db.attendanceDao().delete(r) }

    // ---- Settings & Profile ----
    fun setTheme(t: AppTheme) {
        viewModelScope.launch { a.settings.setTheme(t) }
    }

    fun setAccent(color: Long) {
        viewModelScope.launch { a.settings.setAccent(color) }
    }

    fun setTarget(v: Int) {
        viewModelScope.launch { a.settings.setTarget(v) }
    }

    fun setNotifications(v: Boolean) {
        viewModelScope.launch { a.settings.setNotifications(v) }
    }

    fun rescheduleReminders() = io {
        ReminderScheduler.scheduleAll(ctx, db.timetableDao().allOnce())
    }

    fun setProfile(name: String, subtitle: String) {
        viewModelScope.launch { a.settings.setProfile(name, subtitle) }
    }

    fun completeOnboarding(name: String, subtitle: String) {
        viewModelScope.launch {
            a.settings.setProfile(name, subtitle)
            a.settings.setOnboardingDone(true)
        }
    }

    // ---- OCR ----
    fun scan(uri: Uri) {
        scanning.value = true
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { TimetableOcr.scan(ctx, uri, subjects.value) }
                if (result.isEmpty()) {
                    message.tryEmit("No classes detected. Try a clearer image or add classes manually.")
                } else {
                    drafts.value = result
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message.tryEmit("Could not read the image: ${e.message ?: "unknown error"}")
            } finally {
                scanning.value = false
            }
        }
    }

    fun discardDrafts() {
        drafts.value = null
    }

    fun saveDrafts(list: List<DraftEntry>) = io {
        var saved = 0
        list.forEach { d ->
            val sid = d.subjectId ?: return@forEach
            val e = TimetableEntry(
                subjectId = sid,
                dayOfWeek = d.day,
                startMin = d.startMin,
                endMin = d.endMin,
                room = d.room
            )
            val id = db.timetableDao().insert(e)
            ReminderScheduler.schedule(ctx, e.copy(id = id))
            saved++
        }
        drafts.value = null
        message.tryEmit("$saved class${if (saved == 1) "" else "es"} added to timetable")
    }

    // ---- Backup / restore ----
    fun exportTo(uri: Uri) = io {
        val json = BackupManager.export(db)
        val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: error("Could not open the file for writing")
        out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
        message.tryEmit("Backup saved")
    }

    fun importFrom(uri: Uri) = io {
        val input = ctx.contentResolver.openInputStream(uri) ?: error("Could not open the file")
        val text = input.use { it.readBytes().toString(Charsets.UTF_8) }
        val old = db.timetableDao().allOnce()
        BackupManager.import(db, text)
        old.forEach { ReminderScheduler.cancel(ctx, it.id) }
        ReminderScheduler.scheduleAll(ctx, db.timetableDao().allOnce())
        message.tryEmit("Backup restored")
    }
}

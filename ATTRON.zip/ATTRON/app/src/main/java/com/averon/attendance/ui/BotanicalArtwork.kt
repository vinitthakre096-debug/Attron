package com.averon.attendance.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AppTheme

/**
 * Stylized ATTRON 'A' emblem with an integrated botanical leaf on the crossbar,
 * matching the Splash screen, Home top-left brand icon, and Notification icon.
 */
@Composable
fun AttronLeafLogo(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    primaryGreen: Color = Color(0xFF3E7B3B)
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Left & Right serif-inspired 'A' strokes
        val aPath = Path().apply {
            moveTo(w * 0.16f, h * 0.86f)
            lineTo(w * 0.48f, h * 0.14f)
            lineTo(w * 0.54f, h * 0.14f)
            lineTo(w * 0.84f, h * 0.86f)
            lineTo(w * 0.72f, h * 0.86f)
            lineTo(w * 0.50f, h * 0.30f)
            lineTo(w * 0.26f, h * 0.86f)
            close()
        }
        drawPath(
            path = aPath,
            brush = Brush.verticalGradient(
                listOf(Color(0xFF5CA34E), primaryGreen, Color(0xFF2B5B29))
            )
        )

        // Botanical leaf sweeping across the crossbar of 'A'
        val leafPath = Path().apply {
            moveTo(w * 0.32f, h * 0.64f)
            quadraticTo(w * 0.52f, h * 0.44f, w * 0.76f, h * 0.48f)
            quadraticTo(w * 0.62f, h * 0.70f, w * 0.32f, h * 0.64f)
            close()
        }
        drawPath(
            path = leafPath,
            brush = Brush.horizontalGradient(
                listOf(Color(0xFF7EC255), Color(0xFF4B8B47))
            )
        )
    }
}

/**
 * Scenic mountain valley & warm sky illustration matching the Splash screen,
 * Home Dashboard backdrop, and Theme selector previews (Breeze, Dusk, Dark).
 */
@Composable
fun ValleyScenicBackdrop(
    theme: AppTheme,
    modifier: Modifier = Modifier,
    showSun: Boolean = true
) {
    val skyColors = when (theme) {
        AppTheme.BREEZE -> listOf(
            Color(0xFFD5E6EE),
            Color(0xFFEBF2EA),
            Color(0xFFFAF3DE)
        )
        AppTheme.DUSK -> listOf(
            Color(0xFF6A7BA8),
            Color(0xFFC596B8),
            Color(0xFFF3B88C)
        )
        AppTheme.DARK -> listOf(
            Color(0xFF191D28),
            Color(0xFF282D3B),
            Color(0xFF3A3E4C)
        )
    }

    val farMountain = when (theme) {
        AppTheme.BREEZE -> Color(0xFFAEBEAA)
        AppTheme.DUSK -> Color(0xFF6B5D82)
        AppTheme.DARK -> Color(0xFF252933)
    }
    val midMountain = when (theme) {
        AppTheme.BREEZE -> Color(0xFF88A47E)
        AppTheme.DUSK -> Color(0xFF504569)
        AppTheme.DARK -> Color(0xFF1E222A)
    }
    val nearHill = when (theme) {
        AppTheme.BREEZE -> Color(0xFF678E5B)
        AppTheme.DUSK -> Color(0xFF39324F)
        AppTheme.DARK -> Color(0xFF171A20)
    }
    val mistColor = when (theme) {
        AppTheme.BREEZE -> Color(0xFFF7F5EE)
        AppTheme.DUSK -> Color(0xFF262233)
        AppTheme.DARK -> Color(0xFF1B1F23)
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Sky gradient
        drawRect(
            brush = Brush.verticalGradient(skyColors),
            size = size
        )

        // Glowing sun disc
        if (showSun) {
            val sunCenter = Offset(w * 0.48f, h * 0.56f)
            val sunGlow = if (theme == AppTheme.DARK) Color(0x33DCE6F5) else Color(0xAAFFF5D6)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(sunGlow, Color.Transparent),
                    center = sunCenter,
                    radius = w * 0.35f
                ),
                radius = w * 0.35f,
                center = sunCenter
            )
            if (theme != AppTheme.DARK) {
                drawCircle(
                    color = Color(0xFFFFFBEB),
                    radius = w * 0.045f,
                    center = sunCenter
                )
            }
        }

        // Far layered mountain ridge
        val ridge1 = Path().apply {
            moveTo(0f, h * 0.68f)
            lineTo(w * 0.18f, h * 0.52f)
            lineTo(w * 0.42f, h * 0.62f)
            lineTo(w * 0.72f, h * 0.46f)
            lineTo(w, h * 0.58f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(ridge1, farMountain)

        // Mid valley ridge
        val ridge2 = Path().apply {
            moveTo(0f, h * 0.64f)
            lineTo(w * 0.28f, h * 0.74f)
            lineTo(w * 0.62f, h * 0.56f)
            lineTo(w * 0.88f, h * 0.64f)
            lineTo(w, h * 0.60f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(ridge2, midMountain)

        // Foreground lush slope
        val ridge3 = Path().apply {
            moveTo(0f, h * 0.74f)
            quadraticTo(w * 0.35f, h * 0.86f, w * 0.68f, h * 0.72f)
            quadraticTo(w * 0.86f, h * 0.66f, w, h * 0.73f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(ridge3, nearHill)

        // Soft bottom mist fade
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, mistColor.copy(alpha = 0.85f)),
                startY = h * 0.76f,
                endY = h
            ),
            size = size
        )
    }
}

/**
 * Corner botanical green leaf sprig overlay matching the Splash, Timetable, Theme, and More screens.
 */
@Composable
fun CornerBotanicalLeaves(
    modifier: Modifier = Modifier,
    flipHorizontal: Boolean = false,
    flipVertical: Boolean = false
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        fun drawSingleLeaf(cx: Float, cy: Float, lw: Float, lh: Float, angleDeg: Float, c1: Color, c2: Color) {
            rotate(degrees = angleDeg, pivot = Offset(cx, cy)) {
                val path = Path().apply {
                    moveTo(cx, cy)
                    quadraticTo(cx + lw * 0.5f, cy - lh * 0.6f, cx + lw, cy)
                    quadraticTo(cx + lw * 0.5f, cy + lh * 0.6f, cx, cy)
                    close()
                }
                drawPath(path, Brush.linearGradient(listOf(c1, c2), Offset(cx, cy), Offset(cx + lw, cy)))
                drawLine(
                    color = Color(0x55FFFFFF),
                    start = Offset(cx + lw * 0.08f, cy),
                    end = Offset(cx + lw * 0.82f, cy),
                    strokeWidth = 1.5f,
                    cap = StrokeCap.Round
                )
            }
        }

        val scaleX = if (flipHorizontal) -1f else 1f
        val scaleY = if (flipVertical) -1f else 1f
        val baseX = if (flipHorizontal) w else 0f
        val baseY = if (flipVertical) h else 0f

        // Graceful curving stem
        val stem = Path().apply {
            moveTo(baseX, baseY)
            quadraticTo(
                baseX + scaleX * w * 0.45f,
                baseY + scaleY * h * 0.25f,
                baseX + scaleX * w * 0.82f,
                baseY + scaleY * h * 0.65f
            )
        }
        drawPath(stem, Color(0xFF6B9E44), style = Stroke(width = 3f, cap = StrokeCap.Round))

        val leafGreens = listOf(
            Color(0xFF8FD14F) to Color(0xFF4F9236),
            Color(0xFFA3DF5E) to Color(0xFF5FA33E),
            Color(0xFF7BC143) to Color(0xFF3E7C2B)
        )

        drawSingleLeaf(
            baseX + scaleX * w * 0.18f, baseY + scaleY * h * 0.14f,
            w * 0.36f, h * 0.20f,
            if (flipHorizontal) 155f else 25f,
            leafGreens[0].first, leafGreens[0].second
        )
        drawSingleLeaf(
            baseX + scaleX * w * 0.36f, baseY + scaleY * h * 0.26f,
            w * 0.40f, h * 0.22f,
            if (flipHorizontal) 210f else -28f,
            leafGreens[1].first, leafGreens[1].second
        )
        drawSingleLeaf(
            baseX + scaleX * w * 0.50f, baseY + scaleY * h * 0.40f,
            w * 0.34f, h * 0.18f,
            if (flipHorizontal) 140f else 42f,
            leafGreens[2].first, leafGreens[2].second
        )
        drawSingleLeaf(
            baseX + scaleX * w * 0.64f, baseY + scaleY * h * 0.52f,
            w * 0.32f, h * 0.17f,
            if (flipHorizontal) 195f else -12f,
            leafGreens[0].first, leafGreens[0].second
        )
    }
}

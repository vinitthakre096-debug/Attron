package com.averon.attendance.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.averon.attendance.data.AppTheme

/**
 * Stylized ATTRON 'A' emblem with an integrated botanical leaf on the crossbar,
 * matching the Splash screen, Home top-left brand icon, and Notification icon.
 */
@Composable
fun AttronLeafLogo(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    primaryGreen: Color = Color(0xFF087A43)
) = AttronPremiumLogo(modifier = modifier, size = size, primaryGreen = primaryGreen)

@Composable
fun AttronPremiumLogo(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    primaryGreen: Color = Color(0xFF087A43)
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val mark = Path().apply {
            moveTo(w * .50f, h * .06f)
            quadraticTo(w * .46f, h * .06f, w * .43f, h * .13f)
            lineTo(w * .08f, h * .88f)
            quadraticTo(w * .07f, h * .93f, w * .13f, h * .93f)
            lineTo(w * .34f, h * .93f)
            quadraticTo(w * .42f, h * .93f, w * .47f, h * .84f)
            lineTo(w * .58f, h * .66f)
            quadraticTo(w * .63f, h * .58f, w * .72f, h * .63f)
            lineTo(w * .88f, h * .93f)
            lineTo(w * .98f, h * .93f)
            quadraticTo(w * 1.02f, h * .91f, w * .98f, h * .85f)
            lineTo(w * .57f, h * .12f)
            quadraticTo(w * .54f, h * .06f, w * .50f, h * .06f)
            close()
        }
        drawPath(mark, brush = Brush.linearGradient(listOf(Color(0xFF78D94C), primaryGreen, Color(0xFF034B32))))
        val sparkle = Path().apply {
            moveTo(w * .50f, h * .43f)
            quadraticTo(w * .53f, h * .53f, w * .66f, h * .57f)
            quadraticTo(w * .53f, h * .61f, w * .50f, h * .73f)
            quadraticTo(w * .47f, h * .61f, w * .34f, h * .57f)
            quadraticTo(w * .47f, h * .53f, w * .50f, h * .43f)
            close()
        }
        drawPath(sparkle, color = Color.White)
    }
}

/**
 * Scenic mountain valley & warm sky illustration matching the Splash screen,
 * Home Dashboard backdrop, and Theme selector previews (Breeze, Dusk, Dark).
 */
@Composable
fun ValleyScenicBackdrop(
    theme: AppTheme,
    modifier: Modifier = Modifier,
    showSun: Boolean = true
) {
    val skyColors = when (theme) {
        AppTheme.BREEZE -> listOf(
            Color(0xFFD5E6EE),
            Color(0xFFEBF2EA),
            Color(0xFFFAF3DE)
        )
        AppTheme.LAVENDER -> listOf(
            Color(0xFF6A7BA8),
            Color(0xFFC596B8),
            Color(0xFFF3B88C)
        )
        AppTheme.MIDNIGHT -> listOf(Color(0xFF101B20), Color(0xFF20343B), Color(0xFF31484E))
        AppTheme.MOCHA -> listOf(Color(0xFFE7D4C0), Color(0xFFF1E5D7), Color(0xFFB99B7B))
        AppTheme.ARCTIC -> listOf(Color(0xFFD8EAF7), Color(0xFFEAF4FB), Color(0xFFB5D5E9))
        AppTheme.ROSE -> listOf(Color(0xFFEAD1DC), Color(0xFFF7E9EF), Color(0xFFD9AFC1))
    }

    val farMountain = when (theme) {
        AppTheme.BREEZE -> Color(0xFFAEBEAA)
        AppTheme.LAVENDER -> Color(0xFF6B5D82)
        AppTheme.MIDNIGHT -> Color(0xFF252933)
        AppTheme.MOCHA -> Color(0xFFC5A98E)
        AppTheme.ARCTIC -> Color(0xFFB5D2E4)
        AppTheme.ROSE -> Color(0xFFD6AFC0)
    }
    val midMountain = when (theme) {
        AppTheme.BREEZE -> Color(0xFF88A47E)
        AppTheme.LAVENDER -> Color(0xFF504569)
        AppTheme.MIDNIGHT -> Color(0xFF1E222A)
        AppTheme.MOCHA -> Color(0xFFAA896B)
        AppTheme.ARCTIC -> Color(0xFF8FB7D1)
        AppTheme.ROSE -> Color(0xFFC78FA8)
    }
    val nearHill = when (theme) {
        AppTheme.BREEZE -> Color(0xFF678E5B)
        AppTheme.LAVENDER -> Color(0xFF39324F)
        AppTheme.MIDNIGHT -> Color(0xFF171A20)
        AppTheme.MOCHA -> Color(0xFF8F7058)
        AppTheme.ARCTIC -> Color(0xFF6E9FBE)
        AppTheme.ROSE -> Color(0xFFB87995)
    }
    val mistColor = when (theme) {
        AppTheme.BREEZE -> Color(0xFFF7F5EE)
        AppTheme.LAVENDER -> Color(0xFF262233)
        AppTheme.MIDNIGHT -> Color(0xFF1B1F23)
        AppTheme.MOCHA -> Color(0xFFF7F1E9)
        AppTheme.ARCTIC -> Color(0xFFF0F7FC)
        AppTheme.ROSE -> Color(0xFFFCF3F6)
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Sky gradient
        drawRect(
            brush = Brush.verticalGradient(skyColors),
            size = size
        )

        // Glowing sun disc
        if (showSun) {
            val sunCenter = Offset(w * 0.48f, h * 0.56f)
            val sunGlow = if (theme == AppTheme.MIDNIGHT) Color(0x33DCE6F5) else Color(0xAAFFF5D6)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(sunGlow, Color.Transparent),
                    center = sunCenter,
                    radius = w * 0.35f
                ),
                radius = w * 0.35f,
                center = sunCenter
            )
            if (theme != AppTheme.MIDNIGHT) {
                drawCircle(
                    color = Color(0xFFFFFBEB),
                    radius = w * 0.045f,
                    center = sunCenter
                )
            }
        }

        // Far layered mountain ridge
        val ridge1 = Path().apply {
            moveTo(0f, h * 0.68f)
            lineTo(w * 0.18f, h * 0.52f)
            lineTo(w * 0.42f, h * 0.62f)
            lineTo(w * 0.72f, h * 0.46f)
            lineTo(w, h * 0.58f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(ridge1, farMountain)

        // Mid valley ridge
        val ridge2 = Path().apply {
            moveTo(0f, h * 0.64f)
            lineTo(w * 0.28f, h * 0.74f)
            lineTo(w * 0.62f, h * 0.56f)
            lineTo(w * 0.88f, h * 0.64f)
            lineTo(w, h * 0.60f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(ridge2, midMountain)

        // Foreground lush slope
        val ridge3 = Path().apply {
            moveTo(0f, h * 0.74f)
            quadraticTo(w * 0.35f, h * 0.86f, w * 0.68f, h * 0.72f)
            quadraticTo(w * 0.86f, h * 0.66f, w, h * 0.73f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(ridge3, nearHill)

        // Soft bottom mist fade
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, mistColor.copy(alpha = 0.85f)),
                startY = h * 0.76f,
                endY = h
            ),
            size = size
        )
    }
}

/**
 * Corner botanical green leaf sprig overlay matching the Splash, Timetable, Theme, and More screens.
 */
@Composable
fun CornerBotanicalLeaves(
    modifier: Modifier = Modifier,
    flipHorizontal: Boolean = false,
    flipVertical: Boolean = false
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        fun drawSingleLeaf(cx: Float, cy: Float, lw: Float, lh: Float, angleDeg: Float, c1: Color, c2: Color) {
            rotate(degrees = angleDeg, pivot = Offset(cx, cy)) {
                val path = Path().apply {
                    moveTo(cx, cy)
                    quadraticTo(cx + lw * 0.5f, cy - lh * 0.6f, cx + lw, cy)
                    quadraticTo(cx + lw * 0.5f, cy + lh * 0.6f, cx, cy)
                    close()
                }
                drawPath(path, Brush.linearGradient(listOf(c1, c2), Offset(cx, cy), Offset(cx + lw, cy)))
                drawLine(
                    color = Color(0x55FFFFFF),
                    start = Offset(cx + lw * 0.08f, cy),
                    end = Offset(cx + lw * 0.82f, cy),
                    strokeWidth = 1.5f,
                    cap = StrokeCap.Round
                )
            }
        }

        val scaleX = if (flipHorizontal) -1f else 1f
        val scaleY = if (flipVertical) -1f else 1f
        val baseX = if (flipHorizontal) w else 0f
        val baseY = if (flipVertical) h else 0f

        // Graceful curving stem
        val stem = Path().apply {
            moveTo(baseX, baseY)
            quadraticTo(
                baseX + scaleX * w * 0.45f,
                baseY + scaleY * h * 0.25f,
                baseX + scaleX * w * 0.82f,
                baseY + scaleY * h * 0.65f
            )
        }
        drawPath(stem, Color(0xFF6B9E44), style = Stroke(width = 3f, cap = StrokeCap.Round))

        val leafGreens = listOf(
            Color(0xFF8FD14F) to Color(0xFF4F9236),
            Color(0xFFA3DF5E) to Color(0xFF5FA33E),
            Color(0xFF7BC143) to Color(0xFF3E7C2B)
        )

        drawSingleLeaf(
            baseX + scaleX * w * 0.18f, baseY + scaleY * h * 0.14f,
            w * 0.36f, h * 0.20f,
            if (flipHorizontal) 155f else 25f,
            leafGreens[0].first, leafGreens[0].second
        )
        drawSingleLeaf(
            baseX + scaleX * w * 0.36f, baseY + scaleY * h * 0.26f,
            w * 0.40f, h * 0.22f,
            if (flipHorizontal) 210f else -28f,
            leafGreens[1].first, leafGreens[1].second
        )
        drawSingleLeaf(
            baseX + scaleX * w * 0.50f, baseY + scaleY * h * 0.40f,
            w * 0.34f, h * 0.18f,
            if (flipHorizontal) 140f else 42f,
            leafGreens[2].first, leafGreens[2].second
        )
        drawSingleLeaf(
            baseX + scaleX * w * 0.64f, baseY + scaleY * h * 0.52f,
            w * 0.32f, h * 0.17f,
            if (flipHorizontal) 195f else -12f,
            leafGreens[0].first, leafGreens[0].second
        )
    }
}

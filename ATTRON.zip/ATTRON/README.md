# ATTRON - Android attendance app

Kotlin + Jetpack Compose + Room (MVVM), offline-first, minSdk 28, targetSdk 36.
Package: `com.averon.attendance`

## Features implemented
- Home: overall % ring, present/absent/total, day selector, next class, quick Present/Absent/Off, recent activity
- Subjects: name, short name, colour, stats, All / Replacement / Extra views, edit and delete
- Attendance: Present / Absent / Off (Off is excluded from the percentage)
- Weekly timetable (Mon-Sun), room, extra flag, active toggle
- Timetable image scanner (ML Kit OCR) with an editable preview; nothing is saved until you confirm
- Replacement classes (attendance counts for the subject actually taught) and extra classes
- Lecture-end notifications with Present / Absent / Off buttons, boot/time-change rescheduling,
  duplicate prevention, cancel on delete/deactivate
- Reports: overall + subject-wise, monthly summary, trend chart, history (editable), replacement and extra lists
- Goal and shortage calculator (classes to attend / classes you can miss)
- JSON backup and restore (validated before anything is changed, confirmation before replacing)
- Six coordinated themes: Breeze, Midnight, Lavender, Mocha, Arctic and Rose
- Six independent Home backgrounds: Mountain, Arch Studio, Dream Cloud, Glass Orbs, Ocean Texture and Misty Forest
- Background gallery with preview-before-apply and reset to Mountain; selections persist in DataStore
- A5 Premium A-mark identity with gradient primary mark, flat/dark A5 Premium adaptive icon treatment and ATTRON wordmark

## Known limits
- Reminders use AlarmManager. Battery optimisation or force-stop can delay or block them.
- OCR works best on clean, table-like text where each line has a time range like `9:00-10:00`.
  Always review the preview.
- This project has not been compiled by its author. If the first build fails, send the error log.

## Build without a computer (GitHub Actions)

Option A: one-file upload (easiest on a phone)
1. Create a free GitHub account and a new empty repository (browser, "Desktop site" mode helps).
2. Add file > Upload files > upload `ATTRON.zip` to the repository root. Commit.
3. Add file > Create new file. Name it `.github/workflows/build.yml`.
   Paste the full contents of `build-from-zip.yml`. Commit.
4. Open the Actions tab. The "Build ATTRON APK (from zip)" run starts automatically (about 5-10 min).
5. Open the finished run, scroll to Artifacts, download `ATTRON-debug-apk`, unzip it, install `app-debug.apk`
   (allow "Install unknown apps" for your browser/file manager).

Option B: normal repo
Push the unzipped project to a repository. `.github/workflows/build.yml` builds it on every push.

Option C: Android Studio
Open the `ATTRON` folder and press Run.


## Design update (v2.1)
- Theme and background preferences are stored separately. Changing one does not change the other.
- Home background gallery previews the selected image/illustration before applying it.
- The original Mountain background remains the default.
- The home header and splash branding use the A5-inspired geometric A mark.

## Follow-up fixes in this package
- Reports tab and selected subject are saveable across navigation; Android system Back closes subject detail before leaving Reports.
- Calendar month and selected date are saveable; month arrows update the displayed month and horizontal swipes on the calendar grid change months.
- Reminder boot receiver is present for BOOT_COMPLETED, package replacement, and time/time-zone changes. Android/OEM background restrictions can still prevent timely delivery; enable ATTRON auto-launch/background activity and allow unrestricted battery use in device settings.

Build note: this source package was not compiled in this environment because the Android Gradle toolchain is unavailable. Run the included GitHub Actions workflow and install the resulting APK only after checking the build succeeds.
